
In this task, you will create three tenant namespaces with structured labels and annotations that form the foundation for resource isolation.

## Step 1: Create Tenant Namespaces

Create the three tenant namespaces. Run each command in the **Terminal** tab:

```bash
kubectl create namespace team-alpha
```

```bash
kubectl create namespace team-beta
```

```bash
kubectl create namespace team-gamma
```

## Step 2: Apply Tenant Labels

Label each namespace with team identification and environment metadata. These labels will be used by NetworkPolicies and ResourceQuotas in later tasks.

```bash
kubectl label namespace team-alpha team=alpha environment=production tier=paid
```

```bash
kubectl label namespace team-beta team=beta environment=staging tier=paid
```

```bash
kubectl label namespace team-gamma team=gamma environment=development tier=free
```

## Step 3: Apply Tenant Annotations

Annotate each namespace with ownership and contact information. Create the annotation manifest in the **Manifests** tab as `namespace-annotations.yaml`:

```yaml
apiVersion: v1
kind: Namespace
metadata:
  name: team-alpha
  annotations:
    platform.tekanaid.com/owner: "alpha-team-lead@example.com"
    platform.tekanaid.com/cost-center: "cc-1001"
    platform.tekanaid.com/tenant-class: "standard"
---
apiVersion: v1
kind: Namespace
metadata:
  name: team-beta
  annotations:
    platform.tekanaid.com/owner: "beta-team-lead@example.com"
    platform.tekanaid.com/cost-center: "cc-1002"
    platform.tekanaid.com/tenant-class: "standard"
---
apiVersion: v1
kind: Namespace
metadata:
  name: team-gamma
  annotations:
    platform.tekanaid.com/owner: "gamma-team-lead@example.com"
    platform.tekanaid.com/cost-center: "cc-1003"
    platform.tekanaid.com/tenant-class: "basic"
```

Apply the annotations in the **Terminal** tab:

```bash
kubectl apply -f /root/multi-tenant/manifests/namespace-annotations.yaml
```

## Step 4: Verify Namespace Configuration

Verify all three namespaces exist with their labels:

```bash
kubectl get namespaces -l tier --show-labels
```

Verify annotations on team-alpha:

```bash
kubectl get namespace team-alpha -o jsonpath='{.metadata.annotations}' | python3 -m json.tool
```

## Success Criteria

You have successfully completed this task when:
- Three tenant namespaces (team-alpha, team-beta, team-gamma) exist
- All namespaces have team, environment, and tier labels
- All namespaces have platform annotations for ownership and cost tracking
