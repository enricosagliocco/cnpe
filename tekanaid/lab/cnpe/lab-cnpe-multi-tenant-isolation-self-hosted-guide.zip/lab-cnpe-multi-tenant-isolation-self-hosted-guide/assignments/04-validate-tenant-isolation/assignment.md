
In this task, you will deploy workloads in each tenant namespace, verify all isolation dimensions, and create a reusable tenant onboarding script.

## Step 1: Deploy Tenant Workloads

Deploy a sample application in each tenant namespace. Create the manifest in the **Manifests** tab as `tenant-workloads.yaml`:

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: tenant-app
  namespace: team-alpha
spec:
  replicas: 2
  selector:
    matchLabels:
      app: tenant-app
      team: alpha
  template:
    metadata:
      labels:
        app: tenant-app
        team: alpha
    spec:
      containers:
      - name: nginx
        image: nginx:1.27
        ports:
        - containerPort: 80
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: tenant-app
  namespace: team-beta
spec:
  replicas: 2
  selector:
    matchLabels:
      app: tenant-app
      team: beta
  template:
    metadata:
      labels:
        app: tenant-app
        team: beta
    spec:
      containers:
      - name: nginx
        image: nginx:1.27
        ports:
        - containerPort: 80
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: tenant-app
  namespace: team-gamma
spec:
  replicas: 1
  selector:
    matchLabels:
      app: tenant-app
      team: gamma
  template:
    metadata:
      labels:
        app: tenant-app
        team: gamma
    spec:
      containers:
      - name: nginx
        image: nginx:1.27
        ports:
        - containerPort: 80
```

Apply in the **Terminal** tab:

```bash
kubectl apply -f /root/multi-tenant/manifests/tenant-workloads.yaml
```

Wait for all deployments to be ready:

```bash
kubectl wait --for=condition=Available deployment/tenant-app -n team-alpha --timeout=120s
```

```bash
kubectl wait --for=condition=Available deployment/tenant-app -n team-beta --timeout=120s
```

```bash
kubectl wait --for=condition=Available deployment/tenant-app -n team-gamma --timeout=120s
```

## Step 2: Verify Resource Quota Consumption

Check how much of each tenant's quota is consumed after deploying workloads:

```bash
kubectl get resourcequota tenant-quota -n team-alpha -o custom-columns='NAME:.metadata.name,CPU_REQ:.status.used.requests\.cpu,CPU_LIM:.status.used.limits\.cpu,MEM_REQ:.status.used.requests\.memory,MEM_LIM:.status.used.limits\.memory,PODS:.status.used.pods'
```

```bash
kubectl get resourcequota tenant-quota -n team-gamma -o custom-columns='NAME:.metadata.name,CPU_REQ:.status.used.requests\.cpu,CPU_LIM:.status.used.limits\.cpu,MEM_REQ:.status.used.requests\.memory,MEM_LIM:.status.used.limits\.memory,PODS:.status.used.pods'
```

Now test that team-gamma cannot exceed its pod quota. Try to scale beyond the 5-pod limit:

```bash
kubectl scale deployment/tenant-app -n team-gamma --replicas=6
```

Check the deployment status -- it should show unavailable replicas because of the quota:

```bash
kubectl get deployment tenant-app -n team-gamma
```

Scale back down to respect the quota:

```bash
kubectl scale deployment/tenant-app -n team-gamma --replicas=1
```

## Step 3: Verify RBAC Isolation

Create a ServiceAccount per tenant and verify cross-namespace access is denied. Create the manifest in the **Manifests** tab as `tenant-service-accounts.yaml`:

```yaml
apiVersion: v1
kind: ServiceAccount
metadata:
  name: tenant-admin
  namespace: team-alpha
---
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: tenant-admin
  namespace: team-alpha
rules:
- apiGroups: ["", "apps"]
  resources: ["pods", "deployments", "services", "configmaps"]
  verbs: ["get", "list", "create", "update", "delete"]
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: tenant-admin-binding
  namespace: team-alpha
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: Role
  name: tenant-admin
subjects:
- kind: ServiceAccount
  name: tenant-admin
  namespace: team-alpha
```

Apply and test access:

```bash
kubectl apply -f /root/multi-tenant/manifests/tenant-service-accounts.yaml
```

Test that the tenant-admin can access team-alpha:

```bash
kubectl auth can-i list pods --as=system:serviceaccount:team-alpha:tenant-admin -n team-alpha
```

Test that the tenant-admin cannot access team-beta:

```bash
kubectl auth can-i list pods --as=system:serviceaccount:team-alpha:tenant-admin -n team-beta || echo "DENIED: Cross-namespace access blocked as expected"
```

## Step 4: Create Tenant Onboarding Script

Create a reusable script that automates provisioning a new tenant. Create the file in the **Manifests** tab as `onboard-tenant.sh`:

```bash
#!/bin/bash
set -e

TENANT_NAME="$1"
TIER="${2:-basic}"
OWNER_EMAIL="${3:-admin@example.com}"
COST_CENTER="${4:-cc-0000}"

if [ -z "$TENANT_NAME" ]; then
  echo "Usage: $0 <tenant-name> [tier] [owner-email] [cost-center]"
  exit 1
fi

echo "Onboarding tenant: $TENANT_NAME (tier: $TIER)"

kubectl create namespace "$TENANT_NAME" --dry-run=client -o yaml | kubectl apply -f -
kubectl label namespace "$TENANT_NAME" team="$TENANT_NAME" tier="$TIER" --overwrite
kubectl annotate namespace "$TENANT_NAME" \
  "platform.tekanaid.com/owner=$OWNER_EMAIL" \
  "platform.tekanaid.com/cost-center=$COST_CENTER" --overwrite

if [ "$TIER" = "paid" ]; then
  CPU_REQ="2" MEM_REQ="2Gi" CPU_LIM="4" MEM_LIM="4Gi" PODS="10" PVCS="5"
else
  CPU_REQ="500m" MEM_REQ="512Mi" CPU_LIM="1" MEM_LIM="1Gi" PODS="5" PVCS="2"
fi

kubectl apply -f - <<QUOTA
apiVersion: v1
kind: ResourceQuota
metadata:
  name: tenant-quota
  namespace: $TENANT_NAME
spec:
  hard:
    requests.cpu: "$CPU_REQ"
    requests.memory: "$MEM_REQ"
    limits.cpu: "$CPU_LIM"
    limits.memory: "$MEM_LIM"
    pods: "$PODS"
    persistentvolumeclaims: "$PVCS"
QUOTA

kubectl apply -f - <<NETPOL
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: default-deny-all
  namespace: $TENANT_NAME
spec:
  podSelector: {}
  policyTypes: [Ingress, Egress]
---
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: allow-same-namespace
  namespace: $TENANT_NAME
spec:
  podSelector: {}
  policyTypes: [Ingress, Egress]
  ingress:
  - from:
    - namespaceSelector:
        matchLabels:
          kubernetes.io/metadata.name: $TENANT_NAME
  egress:
  - to:
    - namespaceSelector:
        matchLabels:
          kubernetes.io/metadata.name: $TENANT_NAME
  - to:
    - namespaceSelector:
        matchLabels:
          kubernetes.io/metadata.name: kube-system
    ports:
    - {protocol: UDP, port: 53}
    - {protocol: TCP, port: 53}
NETPOL

echo "Tenant '$TENANT_NAME' onboarded successfully!"
```

Make it executable and test it:

```bash
chmod +x /root/multi-tenant/manifests/onboard-tenant.sh
```

```bash
/root/multi-tenant/manifests/onboard-tenant.sh team-delta paid delta-lead@example.com cc-2001
```

Verify the new tenant was created correctly:

```bash
kubectl get namespace team-delta --show-labels
```

```bash
kubectl get resourcequota -n team-delta
```

```bash
kubectl get networkpolicy -n team-delta
```

## Success Criteria

You have successfully completed this task when:
- Tenant workloads are deployed and running in all three namespaces
- Resource quota consumption is visible and enforcement works (scaling beyond quota fails)
- RBAC isolation prevents cross-namespace access
- The onboarding script successfully provisions a new tenant (team-delta)
