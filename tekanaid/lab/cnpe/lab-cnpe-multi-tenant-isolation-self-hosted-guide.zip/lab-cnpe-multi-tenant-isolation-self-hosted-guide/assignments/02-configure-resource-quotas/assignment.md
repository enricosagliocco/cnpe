
In this task, you will configure ResourceQuotas and LimitRanges for each tenant namespace with different resource tiers.

## Step 1: Create ResourceQuotas

The paid-tier tenants (team-alpha and team-beta) get higher quotas than the free-tier tenant (team-gamma). Create the quota manifest in the **Manifests** tab as `resource-quotas.yaml`:

```yaml
apiVersion: v1
kind: ResourceQuota
metadata:
  name: tenant-quota
  namespace: team-alpha
spec:
  hard:
    requests.cpu: "2"
    requests.memory: 2Gi
    limits.cpu: "4"
    limits.memory: 4Gi
    pods: "10"
    persistentvolumeclaims: "5"
    services: "5"
---
apiVersion: v1
kind: ResourceQuota
metadata:
  name: tenant-quota
  namespace: team-beta
spec:
  hard:
    requests.cpu: "2"
    requests.memory: 2Gi
    limits.cpu: "4"
    limits.memory: 4Gi
    pods: "10"
    persistentvolumeclaims: "5"
    services: "5"
---
apiVersion: v1
kind: ResourceQuota
metadata:
  name: tenant-quota
  namespace: team-gamma
spec:
  hard:
    requests.cpu: "500m"
    requests.memory: 512Mi
    limits.cpu: "1"
    limits.memory: 1Gi
    pods: "5"
    persistentvolumeclaims: "2"
    services: "2"
```

Apply the quotas in the **Terminal** tab:

```bash
kubectl apply -f /root/multi-tenant/manifests/resource-quotas.yaml
```

## Step 2: Create LimitRanges

LimitRanges set defaults so pods without explicit resource requests still get reasonable values. Create the manifest in the **Manifests** tab as `limit-ranges.yaml`:

```yaml
apiVersion: v1
kind: LimitRange
metadata:
  name: tenant-limits
  namespace: team-alpha
spec:
  limits:
  - default:
      cpu: 200m
      memory: 256Mi
    defaultRequest:
      cpu: 100m
      memory: 128Mi
    max:
      cpu: "1"
      memory: 1Gi
    min:
      cpu: 50m
      memory: 64Mi
    type: Container
---
apiVersion: v1
kind: LimitRange
metadata:
  name: tenant-limits
  namespace: team-beta
spec:
  limits:
  - default:
      cpu: 200m
      memory: 256Mi
    defaultRequest:
      cpu: 100m
      memory: 128Mi
    max:
      cpu: "1"
      memory: 1Gi
    min:
      cpu: 50m
      memory: 64Mi
    type: Container
---
apiVersion: v1
kind: LimitRange
metadata:
  name: tenant-limits
  namespace: team-gamma
spec:
  limits:
  - default:
      cpu: 100m
      memory: 128Mi
    defaultRequest:
      cpu: 50m
      memory: 64Mi
    max:
      cpu: 200m
      memory: 256Mi
    min:
      cpu: 25m
      memory: 32Mi
    type: Container
```

Apply the limit ranges:

```bash
kubectl apply -f /root/multi-tenant/manifests/limit-ranges.yaml
```

## Step 3: Verify Quota Configuration

Check the quotas across all tenant namespaces:

```bash
kubectl get resourcequota tenant-quota -n team-alpha
```

```bash
kubectl get resourcequota tenant-quota -n team-gamma
```

Compare the paid vs free tier limits. Notice team-gamma has significantly lower limits:

```bash
kubectl describe limitrange tenant-limits -n team-gamma
```

## Step 4: Test Quota Enforcement

Try to exceed the free-tier quota by creating a pod that requests more memory than allowed. Run in the **Terminal** tab:

```bash
kubectl run quota-test --image=nginx:1.27 --namespace=team-gamma --restart=Never --overrides='{"spec":{"containers":[{"name":"quota-test","image":"nginx:1.27","resources":{"requests":{"memory":"512Mi"},"limits":{"memory":"512Mi"}}}]}}'
```

This should fail because 512Mi exceeds team-gamma's max container memory of 256Mi. You should see an error like "must be less than or equal to memory limit".

Clean up the failed attempt (in case it partially succeeded):

```bash
kubectl delete pod quota-test -n team-gamma --ignore-not-found
```

## Success Criteria

You have successfully completed this task when:
- ResourceQuotas are applied to all three tenant namespaces
- LimitRanges are applied with different tiers for paid vs free tenants
- Quota enforcement blocks pods that exceed container limits
