
In this task, you will create NetworkPolicies that deny all inter-tenant traffic by default and allow only intra-namespace communication.

## Step 1: Create Default-Deny Policies

A default-deny policy blocks all ingress and egress traffic unless explicitly allowed. Create the manifest in the **Manifests** tab as `default-deny.yaml`:

```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: default-deny-all
  namespace: team-alpha
spec:
  podSelector: {}
  policyTypes:
  - Ingress
  - Egress
---
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: default-deny-all
  namespace: team-beta
spec:
  podSelector: {}
  policyTypes:
  - Ingress
  - Egress
---
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: default-deny-all
  namespace: team-gamma
spec:
  podSelector: {}
  policyTypes:
  - Ingress
  - Egress
```

Apply the policies in the **Terminal** tab:

```bash
kubectl apply -f /root/multi-tenant/manifests/default-deny.yaml
```

## Step 2: Allow Intra-Namespace and DNS Traffic

Pods within the same tenant namespace should communicate freely, and all pods need DNS access. Create the manifest in the **Manifests** tab as `allow-same-namespace.yaml`:

```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: allow-same-namespace
  namespace: team-alpha
spec:
  podSelector: {}
  policyTypes:
  - Ingress
  - Egress
  ingress:
  - from:
    - namespaceSelector:
        matchLabels:
          kubernetes.io/metadata.name: team-alpha
  egress:
  - to:
    - namespaceSelector:
        matchLabels:
          kubernetes.io/metadata.name: team-alpha
  - to:
    - namespaceSelector:
        matchLabels:
          kubernetes.io/metadata.name: kube-system
    ports:
    - protocol: UDP
      port: 53
    - protocol: TCP
      port: 53
---
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: allow-same-namespace
  namespace: team-beta
spec:
  podSelector: {}
  policyTypes:
  - Ingress
  - Egress
  ingress:
  - from:
    - namespaceSelector:
        matchLabels:
          kubernetes.io/metadata.name: team-beta
  egress:
  - to:
    - namespaceSelector:
        matchLabels:
          kubernetes.io/metadata.name: team-beta
  - to:
    - namespaceSelector:
        matchLabels:
          kubernetes.io/metadata.name: kube-system
    ports:
    - protocol: UDP
      port: 53
    - protocol: TCP
      port: 53
---
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: allow-same-namespace
  namespace: team-gamma
spec:
  podSelector: {}
  policyTypes:
  - Ingress
  - Egress
  ingress:
  - from:
    - namespaceSelector:
        matchLabels:
          kubernetes.io/metadata.name: team-gamma
  egress:
  - to:
    - namespaceSelector:
        matchLabels:
          kubernetes.io/metadata.name: team-gamma
  - to:
    - namespaceSelector:
        matchLabels:
          kubernetes.io/metadata.name: kube-system
    ports:
    - protocol: UDP
      port: 53
    - protocol: TCP
      port: 53
```

Apply the allow policies:

```bash
kubectl apply -f /root/multi-tenant/manifests/allow-same-namespace.yaml
```

## Step 3: Deploy Test Pods for Connectivity Verification

Deploy a web server and a client pod in team-alpha, and a client pod in team-beta. Create the manifest in the **Manifests** tab as `network-test-pods.yaml`:

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: web-server
  namespace: team-alpha
  labels:
    app: web-server
    team: alpha
spec:
  containers:
  - name: nginx
    image: nginx:1.27
    ports:
    - containerPort: 80
---
apiVersion: v1
kind: Service
metadata:
  name: web-server
  namespace: team-alpha
spec:
  selector:
    app: web-server
  ports:
  - port: 80
    targetPort: 80
---
apiVersion: v1
kind: Pod
metadata:
  name: alpha-client
  namespace: team-alpha
  labels:
    app: client
    team: alpha
spec:
  containers:
  - name: curl
    image: curlimages/curl:8.11.1
    command: ["sleep", "3600"]
---
apiVersion: v1
kind: Pod
metadata:
  name: beta-client
  namespace: team-beta
  labels:
    app: client
    team: beta
spec:
  containers:
  - name: curl
    image: curlimages/curl:8.11.1
    command: ["sleep", "3600"]
```

Apply and wait for the pods to be ready:

```bash
kubectl apply -f /root/multi-tenant/manifests/network-test-pods.yaml
```

```bash
kubectl wait --for=condition=Ready pod/web-server -n team-alpha --timeout=120s
```

```bash
kubectl wait --for=condition=Ready pod/alpha-client -n team-alpha --timeout=120s
```

```bash
kubectl wait --for=condition=Ready pod/beta-client -n team-beta --timeout=120s
```

## Step 4: Verify Network Isolation

Test that intra-namespace traffic works (alpha-client to alpha web-server):

```bash
kubectl exec alpha-client -n team-alpha -- curl -s --max-time 5 http://web-server.team-alpha.svc.cluster.local
```

This should return the nginx welcome page.

Test that cross-namespace traffic is blocked (beta-client to alpha web-server):

```bash
kubectl exec beta-client -n team-beta -- curl -s --max-time 5 http://web-server.team-alpha.svc.cluster.local || echo "BLOCKED: Cross-tenant traffic denied as expected"
```

This should time out, confirming inter-tenant isolation.

## Success Criteria

You have successfully completed this task when:
- Default-deny NetworkPolicies exist in all three tenant namespaces
- Intra-namespace allow policies permit same-tenant traffic and DNS
- Traffic within team-alpha works (alpha-client reaches web-server)
- Cross-namespace traffic from team-beta to team-alpha is blocked
