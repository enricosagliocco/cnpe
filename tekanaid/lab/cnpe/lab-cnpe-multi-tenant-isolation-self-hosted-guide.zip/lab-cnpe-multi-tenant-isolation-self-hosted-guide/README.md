# Multi-Tenant Resource Isolation for Platforms — Self-Hosted Guide

This hands-on lab teaches you to implement multi-tenant resource isolation for your Kubernetes platform.

You'll learn to:

- Design tenant namespaces with labels and annotations for identification

- Configure ResourceQuotas to limit CPU, memory, pod count, and storage per tenant

- Set LimitRanges for default and maximum container resource boundaries

- Implement NetworkPolicies for inter-tenant traffic isolation

- Validate end-to-end tenant isolation across resource, network, and access dimensions

- Create reusable tenant onboarding scripts for consistent provisioning

Multi-tenant resource isolation is a core platform engineering competency tested in the CNPE certification exam (Domain 1: Platform Architecture and Infrastructure, 15%).


**Estimated Time:** 45 minutes
**Difficulty:** intermediate

## Prerequisites

- kubernetes-fundamentals
- namespace-basics
- networking-concepts

## VM Configuration

This lab uses the following VMs:

- **k8s-cluster**: kubernetes-dev2025, medium

## How to Use This Guide

1. Set up your infrastructure (VMs or containers matching the configuration above)
2. Run the lab setup scripts from `scripts/lab/`
3. For each task (in order):
   a. Read the assignment in `assignments/{taskpath}/assignment.md`
   b. Run the task setup script from `scripts/tasks/{taskpath}/`
   c. Try to complete the assignment on your own
   d. If stuck, reference the solve script in `scripts/tasks/{taskpath}/`
4. When done, run the cleanup scripts from `scripts/lab/cleanup-*`

## Tasks

1. Design Tenant Namespaces — `assignments/01-design-tenant-namespaces/`
2. Configure Resource Quotas and Limit Ranges — `assignments/02-configure-resource-quotas/`
3. Implement Network Isolation — `assignments/03-implement-network-isolation/`
4. Validate Tenant Isolation — `assignments/04-validate-tenant-isolation/`
