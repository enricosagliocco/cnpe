
In this task, you'll test provider authentication and create your first AWS managed resources.

## Step 1: Create Your First AWS Resource

Create a VPC to test the complete provider functionality:

### 1.1 Create a test VPC manifest

Create this VPC configuration in the **Manifests** tab as `test-vpc.yaml`:

```yaml
apiVersion: ec2.aws.upbound.io/v1beta1
kind: VPC
metadata:
  name: crossplane-test-vpc
  labels:
    purpose: testing
    managed-by: crossplane
spec:
  forProvider:
    region: us-east-1
    cidrBlock: "192.168.0.0/16"
    enableDnsHostnames: true
    enableDnsSupport: true
    tags:
      Name: "Crossplane Test VPC"
      Environment: "test"
      ManagedBy: "crossplane"
  providerConfigRef:
    name: default
```

### 1.2 Apply the VPC resource

Apply the VPC from the **Terminal** tab:
```bash
kubectl apply -f /root/crossplane/manifests/test-vpc.yaml
```

### 1.3 Monitor VPC creation

Watch the VPC resource status:
```bash
kubectl get vpc crossplane-test-vpc -w
```

Press `Ctrl+C` when you see `READY: True` and `SYNCED: True`.

### 1.4 Check VPC details

Examine the created VPC:
```bash
kubectl describe vpc crossplane-test-vpc
```

Note the AWS VPC ID in the status section.

## Step 2: Verify in AWS Console

Confirm the VPC was created in AWS.

> **Important**: Make sure your region is switched to **US East (N. Virginia)**, which is `us-east-1`, using the dropdown menu in the top right corner of the AWS Console.

### 2.1 Switch to AWS Console tab

Click on the **AWS Console** tab to access the AWS Management Console.

### 2.2 Navigate to VPC service

In the AWS Console:
1. Go to Services → VPC
2. Click "Your VPCs" in the left sidebar

### 2.3 Find your Crossplane-created VPC

Look for a VPC with:
- Name: "Crossplane Test VPC"
- CIDR: 192.168.0.0/16
- Tags showing "ManagedBy: crossplane"

### 2.4 Compare AWS ID with Kubernetes

Back in the **Terminal** tab, get the VPC ID from Kubernetes:
```bash
kubectl get vpc crossplane-test-vpc -o jsonpath='{.status.atProvider.id}' && echo
```

Verify this matches the VPC ID shown in the AWS Console.

## Step 3: Demonstrate Crossplane Reconciliation

Test how Crossplane maintains desired state:

### 3.1 Manually modify VPC in AWS Console

In the **AWS Console** tab:
1. Select your Crossplane VPC
2. Click "Actions" → "Edit VPC settings"
3. Change "Enable DNS hostnames" to disabled
4. Save changes

### 3.2 Watch Crossplane restore desired state

Back in the **Terminal** tab, watch Crossplane detect and fix the drift:
```bash
kubectl get vpc crossplane-test-vpc -w
```

You should see the `SYNCED` status briefly go to `False` then back to `True` as Crossplane restores the desired state.

### 3.3 Verify settings were restored

Check in the **AWS Console** that "Enable DNS hostnames" was automatically restored to enabled.

### 3.4 View Crossplane events

Check events to see the reconciliation activity:
```bash
kubectl get events --sort-by=.metadata.creationTimestamp | tail -10
```

Look for events related to VPC synchronization.

## Success Criteria

✅ **Resource Creation**: VPC created successfully through Crossplane
✅ **AWS Console Verification**: Resource visible and correct in AWS Console
✅ **Reconciliation Loop**: Crossplane automatically corrects configuration drift  

## Key Takeaways

1. **Infrastructure as Code**: Kubernetes resources represent AWS infrastructure
2. **Automatic Reconciliation**: Crossplane continuously ensures actual state matches desired state
3. **Declarative Management**: You declare what you want, Crossplane handles how to achieve it
4. **Unified Interface**: Manage AWS resources using familiar Kubernetes tooling

## Next Steps

In the next task, you'll create a complete VPC with subnets to build a comprehensive networking foundation.