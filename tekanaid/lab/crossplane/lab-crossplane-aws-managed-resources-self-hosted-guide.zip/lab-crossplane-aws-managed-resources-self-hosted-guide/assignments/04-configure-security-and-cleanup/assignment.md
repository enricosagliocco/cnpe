
In this task, you'll learn how to properly clean up all AWS networking resources created by Crossplane to avoid unnecessary charges.

## Step 1: Review Current Infrastructure

Before cleaning up, verify all the resources that currently exist.

### 1.1 Check all Kubernetes resources

Run this command in the **Terminal** tab to see all AWS resources managed by Crossplane:
```bash
kubectl get vpc,subnet,internetgateway,securitygroup,securitygrouprule
```

You should see the platform-vpc, 4 subnets (2 public, 2 private), 1 internet gateway, 2 security groups, and 3 security group rules.

## Step 2: Understand Resource Dependencies

Before deleting resources, understand the dependency order:

**Dependency hierarchy** (delete from bottom to top):
1. **Security Group Rules** → depend on Security Groups
2. **Security Groups** → depend on VPC
3. **Subnets** → depend on VPC
4. **Internet Gateway** → depends on VPC
5. **VPC** → base resource (delete last)

⚠️ **Important**: Always delete in reverse dependency order to avoid errors!

## Step 3: Delete Security Resources First

Start by deleting security group rules, which are at the top of the dependency chain.

### 3.1 Delete security group rules

Delete all security group rules in the **Terminal** tab:
```bash
kubectl delete securitygrouprule --all
```

### 3.2 Verify rules are deleted

Verify the rules are gone:
```bash
kubectl get securitygrouprule
```

You should see "No resources found".

## Step 4: Delete Security Groups

Now that rules are deleted, remove the security groups.

### 4.1 Delete security groups

Delete all security groups in the **Terminal** tab:
```bash
kubectl delete securitygroup --all
```

### 4.2 Verify security groups are deleted

Check that security groups are gone:
```bash
kubectl get securitygroup
```

You should see "No resources found".

## Step 5: Delete Network Components

Remove subnets and internet gateway.

### 5.1 Delete all subnets

Delete both public and private subnets:
```bash
kubectl delete subnet --all
```

### 5.2 Delete internet gateway

Delete the internet gateway:
```bash
kubectl delete internetgateway --all
```

### 5.3 Verify network components are deleted

Check that subnets and IGW are gone:
```bash
kubectl get subnet,internetgateway
```

You should see "No resources found" for both resource types.

## Step 6: Delete the VPC

Finally, delete the VPC which was the base resource.

### 6.1 Delete the VPC

Delete the VPC (last resource) in the **Terminal** tab:
```bash
kubectl delete vpc --all
```

### 6.2 Verify all resources are deleted

Check that everything is cleaned up:
```bash
kubectl get vpc,subnet,internetgateway,securitygroup,securitygrouprule
```

You should see "No resources found" for all resource types.

## Step 7: Verify Cleanup in AWS Console

Confirm that AWS resources were also deleted.

### 7.1 Check AWS Console

Switch to the **AWS Console** tab and verify all resources are deleted:

1. **VPC Dashboard**: Your platform-vpc should be gone
2. **Subnets**: All platform subnets should be removed
3. **Internet Gateway**: The platform-igw should be deleted
4. **Security Groups**: Only the default security group should remain

**Note:** Crossplane automatically deletes the corresponding AWS resources when you delete the Kubernetes resources. This may take 1-2 minutes to propagate to the AWS Console.

## Success Criteria

✅ Reviewed all existing AWS resources before cleanup
✅ Understood resource dependency hierarchy
✅ Deleted security group rules first
✅ Deleted security groups second
✅ Deleted subnets and internet gateway
✅ Deleted VPC last
✅ Verified all Kubernetes resources are deleted
✅ Verified all AWS resources are deleted in AWS Console

## Expected Output

After completing all cleanup steps, you should see:
```
$ kubectl get vpc,subnet,internetgateway,securitygroup,securitygrouprule

No resources found.
```

## Platform Engineering Notes

This cleanup task demonstrates critical platform engineering practices:

### Resource Lifecycle Management
- **Proper deletion order**: Understanding and respecting resource dependencies
- **Cascade deletion**: How Crossplane handles AWS resource cleanup automatically
- **Verification**: Confirming deletion in both Kubernetes and AWS

### Cost Management
- **Clean resource deletion**: Preventing unnecessary AWS charges
- **Infrastructure hygiene**: Not leaving orphaned resources
- **Declarative cleanup**: Using `kubectl delete` to remove managed resources

### Dependency Awareness
Understanding the dependency tree is crucial:
```
VPC (base)
├── Subnets (depend on VPC)
├── Internet Gateway (depends on VPC)
└── Security Groups (depend on VPC)
    └── Security Group Rules (depend on Security Groups)
```

Delete from the leaves (rules) down to the root (VPC).

## What You Learned

🎓 **Key Takeaways:**
- How to properly clean up Crossplane-managed AWS resources
- The importance of respecting resource dependencies during deletion
- How Crossplane automatically removes AWS resources when K8s resources are deleted
- Cost management through proper resource cleanup
- Verification of cleanup in both Kubernetes and AWS

## Next Steps

You've successfully completed the AWS Managed Resources lab! You learned how to:
1. Install and configure Crossplane providers
2. Create AWS networking infrastructure (VPC, subnets, gateways, security groups)
3. Properly clean up all resources to avoid charges

In future labs, you'll learn about **Crossplane Compositions** which allow you to create reusable, abstracted infrastructure templates!