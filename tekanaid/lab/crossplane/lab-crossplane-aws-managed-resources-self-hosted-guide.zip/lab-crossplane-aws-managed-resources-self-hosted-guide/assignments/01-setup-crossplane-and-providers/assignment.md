
In this task, you'll set up Crossplane with AWS providers to manage cloud infrastructure through Kubernetes.

## Step 1: Verify Pre-Configured Crossplane Environment

Let's start by verifying that Crossplane is properly installed and running:

### 1.1 Check Crossplane system pods

Run this command in the **Terminal** tab:
```bash
kubectl get pods -n crossplane-system
```

You should see Crossplane core pods running, including:
- `crossplane-*`: Main Crossplane controller
- `crossplane-rbac-manager-*`: RBAC management

### 1.2 Verify Crossplane CRDs are installed

Check that Crossplane has installed its core Custom Resource Definitions:
```bash
kubectl get crds | grep crossplane.io | head -5
```

### 1.3 Check current providers (should be empty initially)

List any existing providers:
```bash
kubectl get providers
```

Initially, this should return "No resources found" since we haven't installed any providers yet.

### 1.4 Verify namespace setup

Ensure you're working in the crossplane-system namespace:
```bash
kubectl config set-context --current --namespace=crossplane-system
```

## Step 2: Install AWS EC2 Provider

Install the AWS EC2 provider to manage networking and compute resources:

### 2.1 Create the AWS EC2 provider manifest

Create this provider configuration in the **Manifests** tab as `aws-ec2-provider.yaml`:

```yaml
apiVersion: pkg.crossplane.io/v1
kind: Provider
metadata:
  name: upbound-provider-aws-ec2
spec:
  package: xpkg.upbound.io/upbound/provider-aws-ec2:v1.23.1
  packagePullPolicy: Always
  revisionActivationPolicy: Automatic
  revisionHistoryLimit: 1
```

### 2.2 Apply the provider configuration

Apply the provider from the **Terminal** tab:
```bash
kubectl apply -f /root/crossplane/manifests/aws-ec2-provider.yaml
```

### 2.3 Monitor provider installation

Watch the provider installation progress:
```bash
kubectl get providers -w
```

Press `Ctrl+C` once you see the provider status shows `INSTALLED: True` and `HEALTHY: True`. This may take 1-2 minutes.

### 2.4 Verify provider CRDs are installed

Check that the provider installed AWS EC2 resource types:
```bash
kubectl get crds | grep aws.upbound.io | head -10
```

You should see CRDs for VPC, Subnet, SecurityGroup, and other AWS EC2 resources.

## Step 3: Create AWS Credentials Secret

Configure secure authentication for AWS:

### 3.1 Check existing AWS credentials

Verify that AWS credentials are available:
```bash
aws configure list
```

You should see configured access key and region information.

### 3.2 Create Kubernetes secret with AWS credentials

Create a secret containing your AWS credentials:
```bash
kubectl create secret generic aws-secret \
  --namespace crossplane-system \
  --from-file=credentials=/root/.aws/credentials
```

### 3.3 Verify the secret was created

Check that the secret exists and contains the credentials:
```bash
kubectl get secret aws-secret -o yaml
```

### 3.4 Check secret data (base64 encoded)

View the secret contents (this will be base64 encoded):
```bash
kubectl get secret aws-secret -o jsonpath='{.data.credentials}' | base64 -d
```

## Step 4: Create ProviderConfig for Authentication

Configure how the AWS provider authenticates with AWS:

### 4.1 Create ProviderConfig manifest

Create this authentication configuration in the **Manifests** tab as `aws-providerconfig.yaml`:

```yaml
apiVersion: aws.upbound.io/v1beta1
kind: ProviderConfig
metadata:
  name: default
spec:
  credentials:
    source: Secret
    secretRef:
      namespace: crossplane-system
      name: aws-secret
      key: credentials
```

### 4.2 Apply the ProviderConfig

Apply the configuration from the **Terminal** tab:
```bash
kubectl apply -f /root/crossplane/manifests/aws-providerconfig.yaml
```

### 4.3 Verify ProviderConfig creation

Check that the ProviderConfig was created:
```bash
kubectl get providerconfig
```

### 4.4 Check ProviderConfig details

Examine the ProviderConfig to ensure it references the correct secret:
```bash
kubectl describe providerconfig.aws.upbound.io/default
```

Look for the secret reference pointing to `aws-secret` in the `crossplane-system` namespace.

## Success Criteria

✅ **Crossplane Running**: Crossplane core pods are healthy and running  
✅ **AWS Provider Installed**: AWS EC2 provider successfully installed and healthy  
✅ **Authentication Configured**: AWS credentials secret created successfully  
✅ **ProviderConfig Ready**: ProviderConfig created and properly configured  

## Key Takeaways

1. **Provider Architecture**: Crossplane uses providers to extend Kubernetes with cloud-specific resources
2. **Secure Authentication**: AWS credentials are stored securely in Kubernetes secrets
3. **ProviderConfig Pattern**: Separates authentication configuration from resource definitions
4. **Installation Verification**: Always verify providers are healthy before using them

## Next Steps

In the next task, you'll test the provider authentication and create your first AWS resources to verify the complete setup works correctly.