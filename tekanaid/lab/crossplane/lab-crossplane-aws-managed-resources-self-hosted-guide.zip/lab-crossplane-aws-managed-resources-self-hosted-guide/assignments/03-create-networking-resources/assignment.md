
In this task, you'll use Crossplane to create a complete AWS networking setup including VPC, subnets, internet gateway, and security groups.

## Step 1: Clean Up and Review Infrastructure Files

Clean up from the previous task and review the pre-created manifest files.

### 1.1 Clean up from previous task

Clean up the test VPC from the previous task in the **Terminal** tab:
```bash
kubectl delete vpc crossplane-test-vpc
```

### 1.2 Verify deletion in AWS Console

Switch to the **AWS Console** tab and verify the VPC was deleted:

1. Navigate to the VPC dashboard (ensure you're in us-east-1 region)
2. Look for the VPC with the name "crossplane-test-vpc"
3. Confirm it's no longer listed in your VPCs
4. If it's still there, wait a few moments and refresh the page

### 1.3 Review the pre-created manifest files

The setup script has already created all the necessary manifest files with detailed comments. Take a few minutes to review the manifest files in the **Manifests** tab. Notice the detailed comments explaining:
- **VPC configuration**: CIDR blocks, DNS settings, and tagging
- **Internet Gateway**: Purpose and attachment strategy
- **Subnet design**: Public vs private subnets, availability zones
- **Security groups**: Layered security approach
- **Label selectors**: How resources dynamically reference each other

## Step 2: Deploy the VPC Foundation

Deploy the core VPC infrastructure that will host all other resources.

### 2.1 Review the VPC manifest

In the **Manifests** tab, open `platform-vpc.yaml` and review:
- **CIDR block**: `10.0.0.0/16` provides 65,536 IP addresses
- **DNS settings**: Required for service discovery
- **Labels**: Used by other resources to reference this VPC

> **📚 Learn More**: For detailed VPC configuration options, see the [Upbound VPC Documentation](https://marketplace.upbound.io/providers/upbound/provider-aws-ec2/v1.23.1/resources/ec2.aws.upbound.io/VPC/v1beta1)

### 2.2 Apply the VPC configuration

Apply the VPC configuration from the **Terminal** tab using the platform-admin service account:
```bash
kubectl apply -f /root/crossplane/manifests/platform-vpc.yaml --as=system:serviceaccount:platform-team:platform-admin
```

### 2.3 Wait for VPC to be ready

Run this command in the **Terminal** tab:
```bash
kubectl wait --for=condition=Ready vpc/platform-vpc --timeout=300s
```

### 2.4 Verify VPC creation

Check the VPC was created successfully:
```bash
kubectl get vpc platform-vpc -o wide
```

## Step 3: Add Internet Connectivity

Deploy the Internet Gateway to enable internet access for public subnets.

### 3.1 Review the Internet Gateway manifest

In the **Manifests** tab, open `platform-igw.yaml` and review:
- **Internet Gateway**: Provides internet access capability
- **VPC Attachment**: Automatically handled via `vpcIdSelector` in the IGW resource
- **Label selectors**: How the IGW finds and attaches to the VPC

> **📚 Learn More**: For detailed Internet Gateway configuration options, see the [Upbound InternetGateway Documentation](https://marketplace.upbound.io/providers/upbound/provider-aws-ec2/v1.23.1/resources/ec2.aws.upbound.io/InternetGateway/v1beta1)

### 3.2 Apply the Internet Gateway

Apply the Internet Gateway from the **Terminal** tab:
```bash
kubectl apply -f /root/crossplane/manifests/platform-igw.yaml --as=system:serviceaccount:platform-team:platform-admin
```

### 3.3 Wait for IGW to be ready

Run this command in the **Terminal** tab:
```bash
kubectl wait --for=condition=Ready internetgateway/platform-igw --timeout=300s
```

### 3.4 Verify IGW and VPC attachment

Run this command to verify the IGW is attached to the VPC:
```bash
kubectl get internetgateway platform-igw -o yaml | grep -A 10 "status:"
```

You should see the VPC ID in the status showing the IGW is attached to your VPC.

## Step 4: Create Public Subnets

Deploy public subnets that can communicate with the internet.

### 4.1 Review the public subnets manifest

In the **Manifests** tab, open `public-subnets.yaml` and review:
- **Two availability zones**: `us-east-1a` and `us-east-1b` for high availability
- **CIDR blocks**: `10.0.1.0/24` and `10.0.2.0/24` (256 IPs each)
- **mapPublicIpOnLaunch**: Automatically assigns public IPs

> **📚 Learn More**: For detailed Subnet configuration options, see the [Upbound Subnet Documentation](https://marketplace.upbound.io/providers/upbound/provider-aws-ec2/v1.23.1/resources/ec2.aws.upbound.io/Subnet/v1beta1)

### 4.2 Apply the public subnets

Apply the public subnets from the **Terminal** tab:
```bash
kubectl apply -f /root/crossplane/manifests/public-subnets.yaml --as=system:serviceaccount:platform-team:platform-admin
```

### 4.3 Wait for subnets to be ready

Run this command in the **Terminal** tab:
```bash
kubectl wait --for=condition=Ready subnet/platform-public-subnet-1a --timeout=300s
```

Then wait for the second public subnet:
```bash
kubectl wait --for=condition=Ready subnet/platform-public-subnet-1b --timeout=300s
```

### 4.4 Check subnet status

Run this command in the **Terminal** tab:
```bash
kubectl get subnets
```

## Step 5: Create Private Subnets

Deploy private subnets for internal resources that don't need direct internet access.

### 5.1 Review the private subnets manifest

In the **Manifests** tab, open `private-subnets.yaml` and review:
- **CIDR blocks**: `10.0.11.0/24` and `10.0.12.0/24` (clearly separated from public)
- **mapPublicIpOnLaunch**: Set to `false` for security
- **Two availability zones**: Same AZs as public subnets for consistency

### 5.2 Apply the private subnets

Apply the private subnets from the **Terminal** tab:
```bash
kubectl apply -f /root/crossplane/manifests/private-subnets.yaml --as=system:serviceaccount:platform-team:platform-admin
```

### 5.3 Wait for private subnets

Run this command in the **Terminal** tab:
```bash
kubectl wait --for=condition=Ready subnet/platform-private-subnet-1a --timeout=300s
```

Then wait for the second private subnet:
```bash
kubectl wait --for=condition=Ready subnet/platform-private-subnet-1b --timeout=300s
```

## Step 6: Create Security Groups

Deploy security groups that act as virtual firewalls for different application tiers.

### 6.1 Review the security groups manifest

In the **Manifests** tab, open `security-groups.yaml` and review:
- **Web tier security group**: For publicly accessible resources
- **Application tier security group**: For internal application servers
- **Tier labels**: Used by security group rules to reference the groups

> **📚 Learn More**: For detailed Security Group configuration options, see the [Upbound SecurityGroup Documentation](https://marketplace.upbound.io/providers/upbound/provider-aws-ec2/v1.23.1/resources/ec2.aws.upbound.io/SecurityGroup/v1beta1)

### 6.2 Apply the security groups

Apply the security groups from the **Terminal** tab:
```bash
kubectl apply -f /root/crossplane/manifests/security-groups.yaml --as=system:serviceaccount:platform-team:platform-admin
```

### 6.3 Wait for security groups

Run this command in the **Terminal** tab:
```bash
kubectl wait --for=condition=Ready securitygroup/platform-web-sg --timeout=300s
```

Then wait for the application security group:
```bash
kubectl wait --for=condition=Ready securitygroup/platform-app-sg --timeout=300s
```

## Step 7: Configure Security Group Rules

Apply specific traffic rules that implement the principle of least privilege.

### 7.1 Review the security group rules manifest

In the **Manifests** tab, open `security-group-rules.yaml` and review:
- **Web tier rules**: Allow HTTP (80) and HTTPS (443) from anywhere
- **Application tier rule**: Allow port 8080 ONLY from web tier
- **Security group chaining**: App tier accepts traffic only from web tier

> **📚 Learn More**: Security group rules are configured as separate resources. For detailed configuration options, see the [Upbound SecurityGroupRule Documentation](https://marketplace.upbound.io/providers/upbound/provider-aws-ec2/v1.23.1/resources/ec2.aws.upbound.io/SecurityGroupRule/v1beta1)

### 7.2 Apply the security group rules

Apply the security group rules from the **Terminal** tab:
```bash
kubectl apply -f /root/crossplane/manifests/security-group-rules.yaml --as=system:serviceaccount:platform-team:platform-admin
```

### 7.3 Wait for rules to be applied

Run this command in the **Terminal** tab to wait for the HTTP ingress rule:
```bash
kubectl wait --for=condition=Ready securitygrouprule/web-http-ingress --timeout=300s
```

Wait for the HTTPS ingress rule:
```bash
kubectl wait --for=condition=Ready securitygrouprule/web-https-ingress --timeout=300s
```

Wait for the application tier ingress rule:
```bash
kubectl wait --for=condition=Ready securitygrouprule/app-from-web-ingress --timeout=300s
```

## Step 8: Verify Complete Infrastructure

Verify that all networking components are deployed and functioning correctly.

### 8.1 Check all resources

Run these commands in the **Terminal** tab to see your complete infrastructure.

Check VPCs:
```bash
kubectl get vpcs
```

Check Subnets:
```bash
kubectl get subnets
```

Check Security Groups:
```bash
kubectl get securitygroups
```

Check Security Group Rules:
```bash
kubectl get securitygrouprules
```

### 8.2 Trace individual managed resources

Use trace commands to understand how managed resources work directly (without compositions):

```bash
crossplane beta trace vpc platform-vpc
```

Then trace a subnet to see resource dependencies:
```bash
crossplane beta trace subnet platform-public-subnet-1a
```

Finally, trace a security group to see complex dependencies:
```bash
crossplane beta trace securitygroup platform-web-sg
```

The trace outputs show:
- **Direct managed resources**: No intermediate composite resources - these are AWS resources managed directly by Crossplane
- **Resource dependencies**: How subnets reference VPCs, security groups reference VPCs, etc.
- **Provider management**: How the upbound-provider-aws-ec2 creates and manages AWS infrastructure
- **Status propagation**: How AWS resource status flows back to Kubernetes

This is **different from compositions** you'll see later - here you're managing AWS resources directly, which is powerful but requires understanding AWS resource relationships. Compositions (in later labs) will abstract this complexity into developer-friendly APIs.

### 8.3 Review in AWS Console

Switch to the **AWS Console** tab and explore your created infrastructure:

1. **VPC Dashboard**: See your `platform-vpc` with DNS enabled
2. **Subnets**: Notice public and private subnets across two availability zones
3. **Internet Gateways**: See your IGW attached to the VPC
4. **Security Groups**: Review the web and app security groups with their rules

This demonstrates how Crossplane creates real AWS infrastructure that you can manage through both Kubernetes and the AWS Console!

## Understanding This Network Setup

### What We Built
This lab creates a **simplified networking foundation** suitable for learning Crossplane concepts:

✅ **VPC** with DNS enabled  
✅ **Internet Gateway** for public internet access  
✅ **Public subnets** (can reach internet) across two availability zones  
✅ **Private subnets** (isolated from internet) for internal resources  
✅ **Security groups** with tiered access rules  

### What's Missing for Production
This is a **basic example** focused on Crossplane learning. A **production-ready setup** would also include:

❌ **NAT Gateway**: Allows private subnets to reach internet for outbound traffic (software updates, API calls)  
❌ **Route Tables**: Explicit routing rules for public (→ IGW) and private (→ NAT) subnet traffic  
❌ **Elastic IPs**: Static IP addresses for NAT Gateway  
❌ **Network ACLs**: Additional subnet-level security (beyond security groups)  
❌ **VPC Endpoints**: Private access to AWS services without internet routing  

### Current Network Behavior
- **Public subnets**: EC2 instances get public IPs and can reach the internet ✅
- **Private subnets**: EC2 instances have no internet access (outbound or inbound) ❌
- **Security groups**: Control traffic between tiers (web → app communication) ✅

This setup is perfect for applications where you want public-facing resources (web servers) in public subnets and backend resources (databases) completely isolated in private subnets.

## Success Criteria

✅ Manifest files created automatically by setup script  
✅ Test VPC from previous task cleaned up  
✅ Production VPC created with DNS enabled  
✅ Internet Gateway attached to VPC  
✅ Public subnets created in multiple AZs  
✅ Private subnets created in multiple AZs  
✅ Security groups configured for web and app tiers  
✅ Security group rules allow appropriate traffic  
✅ All resources have AWS external IDs  
✅ Infrastructure verified in AWS Console  

## Expected Output

When you run the AWS resource status commands, you should see:
```
=== AWS VPCs ===
NAME           READY   SYNCED   EXTERNAL-NAME      AGE
platform-vpc   True    True     vpc-xxxxxxxxxxxxx  5m

=== AWS Subnets ===
NAME                        READY   SYNCED   EXTERNAL-NAME         AGE
platform-public-subnet-1a  True    True     subnet-xxxxxxxxxxxxx  3m
platform-public-subnet-1b  True    True     subnet-xxxxxxxxxxxxx  3m
platform-private-subnet-1a True    True     subnet-xxxxxxxxxxxxx  2m
platform-private-subnet-1b True    True     subnet-xxxxxxxxxxxxx  2m

=== AWS Security Groups ===
NAME              READY   SYNCED   EXTERNAL-NAME      AGE
platform-web-sg  True    True     sg-xxxxxxxxxxxxx   1m
platform-app-sg  True    True     sg-xxxxxxxxxxxxx   1m
```

## Troubleshooting

If you encounter issues:

- **Manifest files missing**: Check that setup script ran with `ls -la /root/crossplane/manifests/`
- **Test VPC not deleted**: Manually delete with `kubectl delete vpc crossplane-test-vpc`
- **Resources stuck in creating**: Check AWS permissions and provider logs
- **Subnet creation fails**: Verify VPC is ready and CIDR blocks don't overlap
- **Security group errors**: Ensure VPC exists and rules reference correct groups
- **Missing external IDs**: Wait longer for AWS synchronization

Debug by running these commands in the **Terminal** tab:
```bash
# Check manifest files were created
ls -la /root/crossplane/manifests/

# Check specific resource status
kubectl describe vpc platform-vpc
kubectl describe subnet platform-public-subnet-1a

# Check provider logs
kubectl logs $(kubectl get pods | grep upbound-provider-aws-ec2 | awk '{print $1}') --tail=50

# Verify AWS connectivity
kubectl get providerconfig -o yaml
```

## Platform Engineering Notes

This networking setup demonstrates:
- **Automated manifest generation**: Setup scripts create infrastructure-as-code templates
- **Multi-AZ resilience**: Resources spread across availability zones
- **Security tiers**: Separate security groups for different application layers
- **Label-based organization**: Consistent labeling for resource management
- **Declarative infrastructure**: All resources defined as Kubernetes manifests with rich comments
- **External resource tracking**: AWS resource IDs maintained in Kubernetes
- **RBAC integration**: Platform admins manage AWS infrastructure securely

### RBAC Pattern Explanation

In this lab, we consistently use the **platform-admin** service account for all AWS infrastructure operations:
- Creating VPCs and networking components
- Managing security groups and rules
- Provisioning subnets across availability zones

This demonstrates the **platform engineering security model** where:
- Platform teams have full control over AWS infrastructure provisioning
- Infrastructure is managed through declarative manifests with proper permissions
- Clear audit trail of who creates what infrastructure resources
- Developers (in future labs) will consume this infrastructure through controlled APIs

This pattern scales to production by:
- Adding more environments (staging, production)
- Including NAT gateways for private subnet internet access
- Implementing network ACLs for additional security
- Adding VPC endpoints for AWS services

## Next Steps

With AWS networking infrastructure in place, you now have:
- A complete VPC foundation ready for applications
- Properly segmented public and private subnets
- Security groups configured for multi-tier applications
- Real AWS resources managed through Kubernetes/Crossplane

This infrastructure is ready for deploying applications, databases, and other AWS services using the same Crossplane patterns!


## Crossplane Documentation References

For building your own AWS networking resources with Crossplane, refer to these official documentation links:

### Core AWS Networking Resources (Upbound AWS EC2 Provider v1.23.1)
- **[VPC](https://marketplace.upbound.io/providers/upbound/provider-aws-ec2/v1.23.1/resources/ec2.aws.upbound.io/VPC/v1beta1)**: Virtual Private Cloud configuration with CIDR blocks, DNS settings, and tagging
- **[Subnet](https://marketplace.upbound.io/providers/upbound/provider-aws-ec2/v1.23.1/resources/ec2.aws.upbound.io/Subnet/v1beta1)**: Public and private subnet creation with availability zone placement
- **[InternetGateway](https://marketplace.upbound.io/providers/upbound/provider-aws-ec2/v1.23.1/resources/ec2.aws.upbound.io/InternetGateway/v1beta1)**: Internet connectivity for public subnets
- **[SecurityGroup](https://marketplace.upbound.io/providers/upbound/provider-aws-ec2/v1.23.1/resources/ec2.aws.upbound.io/SecurityGroup/v1beta1)**: Virtual firewall configuration with ingress and egress rules
- **[SecurityGroupRule](https://marketplace.upbound.io/providers/upbound/provider-aws-ec2/v1.23.1/resources/ec2.aws.upbound.io/SecurityGroupRule/v1beta1)**: Individual security group rules for fine-grained traffic control

### Provider Information
- **[Upbound AWS EC2 Provider](https://marketplace.upbound.io/providers/upbound/provider-aws-ec2/v1.23.1)**: Browse all available AWS EC2 resources and their configurations
- **[Crossplane AWS Quickstart](https://docs.crossplane.io/v1.20/getting-started/provider-aws/)**: Getting started with AWS provider setup
- **[Crossplane Managed Resources](https://docs.crossplane.io/v1.20/concepts/managed-resources/)**: Core concepts for managing cloud resources

### Resource Reference Patterns
The resources in this lab demonstrate key Crossplane patterns:
- **Label selectors**: `vpcIdRef`, `subnetIdRef` for linking resources
- **External references**: Using AWS resource IDs directly
- **Composite resources**: Building reusable infrastructure templates
- **Provider configurations**: Managing AWS credentials and regions