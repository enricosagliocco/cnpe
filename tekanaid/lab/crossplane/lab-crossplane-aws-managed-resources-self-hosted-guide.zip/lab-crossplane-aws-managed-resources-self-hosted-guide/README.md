# AWS Cloud Resources with Crossplane — Self-Hosted Guide

This hands-on lab teaches you to integrate Crossplane with AWS cloud services using minikube for rapid development.

You'll learn to:
- Install and configure AWS EC2 providers in a pre-configured Crossplane environment
- Set up secure AWS authentication using Kubernetes secrets and ProviderConfig
- Test provider authentication and verify cloud resource creation with a test VPC
- Create complete AWS networking infrastructure (VPC, subnets, Internet Gateway)
- Implement multi-tier security architecture with security groups and rules
- Experience Crossplane's reconciliation loop and drift detection
- Understand direct managed resource patterns for platform engineering
- Properly clean up AWS resources in correct dependency order to avoid charges

This lab demonstrates real-world cloud integration patterns while using minikube for fast, reliable learning.

**Estimated Time:** 120 minutes
**Difficulty:** Beginner

## Prerequisites

- crossplane-kubernetes-setup
- aws-credentials-basics
- yaml-configuration

## VM Configuration

This lab uses the following VMs:

- **platform-cluster**: kubernetes-dev2025, small

## How to Use This Guide

1. Set up your infrastructure (VMs or containers matching the configuration above)
2. Run the lab setup scripts from `scripts/lab/`
3. For each task (in order):
   a. Read the assignment in `assignments/{taskpath}/assignment.md`
   b. Run the task setup script from `scripts/tasks/{taskpath}/`
   c. Try to complete the assignment on your own
   d. If stuck, reference the solve script in `scripts/tasks/{taskpath}/`
4. When done, run the cleanup scripts from `scripts/lab/cleanup-*`

## Tasks

1. Setup Crossplane and AWS Providers — `assignments/01-setup-crossplane-and-providers/`
2. Test Providers and Authentication — `assignments/02-test-providers-and-authentication/`
3. Create VPC and Networking Infrastructure — `assignments/03-create-networking-resources/`
4. Clean Up AWS Resources — `assignments/04-configure-security-and-cleanup/`
