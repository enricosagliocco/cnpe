
In this task, you'll install Crossplane using Helm with production-ready settings optimized for platform engineering workloads on your minikube cluster.

## Step 1: Add Crossplane Helm Repository

Add the official Crossplane Helm repository using the **Terminal** tab.

1.1 Run this command in the **Terminal** tab to add the Crossplane Helm repository:
```bash
helm repo add crossplane-stable https://charts.crossplane.io/stable
```

You should see:
```
"crossplane-stable" has been added to your repositories
```

1.2 Run this command in the **Terminal** tab to update Helm repositories:
```bash
helm repo update
```

You should see successful update messages for your repositories.

1.3 Run this command in the **Terminal** tab to verify the repository was added:
```bash
helm search repo crossplane
```

You should see available Crossplane charts listed, including `crossplane-stable/crossplane`.

## Step 2: Create Crossplane Values File

2.1 Create a values file optimized for minikube with production patterns. Create this file in the **Scripts** tab and name it `crossplane-values.yaml`:

**Note:** For more information on Crossplane configuration, see the [Crossplane Installation Guide](https://docs.crossplane.io/v1.20/software/install/).

```yaml
# Production-ready Crossplane configuration optimized for minikube
image:
  tag: v1.20.0

# Resource requirements optimized for minikube
resources:
  limits:
    cpu: 1000m
    memory: 2Gi
  requests:
    cpu: 200m
    memory: 512Mi

# Security settings (production patterns)
securityContext:
  allowPrivilegeEscalation: false
  readOnlyRootFilesystem: true
  runAsNonRoot: true
  runAsUser: 65532
  capabilities:
    drop:
      - ALL

# Enable additional features for platform engineering
args:
  - --debug
  - --enable-composition-revisions
  - --enable-realtime-compositions

# Metrics and monitoring
metrics:
  enabled: true

# Note: Pod disruption budget disabled for single-node minikube
podDisruptionBudget:
  enabled: false

# Optimized for single-node environment
affinity: {}
nodeSelector: {}
tolerations: []
```

## Step 3: Install Crossplane

Install Crossplane using the values file:

3.1 Run these commands in the **Terminal** tab to install Crossplane in the crossplane-system namespace:
```bash
cd /root/crossplane/scripts
helm install crossplane crossplane-stable/crossplane \
  --version 1.20.0 \
  --namespace crossplane-system \
  --values crossplane-values.yaml \
  --wait
```

The `--wait` flag ensures the command waits for Crossplane to be fully deployed. You should see a success message after about 30-60 seconds.

3.2 Change the working namespace to crossplane-system by running this command in the **Terminal** tab:
```bash
kubens crossplane-system
```

You should see:
```
Context "minikube" modified.
Active namespace is "crossplane-system".
```

3.3 Run this command in the **Terminal** tab to verify the Helm installation:
```bash
helm list
```

You should see the Crossplane release listed with status `deployed`.

3.4 Run this command in the **Terminal** tab to check Crossplane pods:
```bash
kubectl get all
```

You should see:
- A Crossplane deployment with 1/1 ready replicas
- A running Crossplane pod
- A Crossplane service

## Step 4: Install Crossplane CLI

Now that Crossplane is running, install the Crossplane CLI (`crossplane`) to help with debugging, development, and managing Crossplane resources. The CLI is essential for platform engineers working with Crossplane compositions and troubleshooting issues.

4.1 Run this command in the **Terminal** tab to install the Crossplane CLI with the latest stable version:
```bash
curl -fsSL -o /tmp/crossplane "https://releases.crossplane.io/stable/v1.20.0/bin/linux_amd64/crank"
```

4.2 Run these commands in the **Terminal** tab to make the CLI executable and move it to the system path:
```bash
chmod +x /tmp/crossplane
mv /tmp/crossplane /usr/local/bin/crossplane
```

4.3 Run this command in the **Terminal** tab to verify the CLI installation:
```bash
crossplane version
```

You should see version output like:
```
v1.20.0
```

**Why the Crossplane CLI is Important:**

The Crossplane CLI provides essential capabilities for platform engineers:

- **Local Development**: Test and render compositions before applying them to clusters
- **Debugging**: Validate configurations and troubleshoot composition issues
- **Resource Management**: View resource relationships and dependencies
- **Development Workflow**: Convert between formats and validate schemas

Having the CLI available will help you in upcoming labs when working with compositions, troubleshooting provider issues, and developing platform abstractions. It's considered a best practice to have the CLI installed alongside Crossplane for development and operations workflows.

## Step 5: Explore Crossplane Resources

Check the Custom Resource Definitions (CRDs) that Crossplane installed and understand their purpose:

5.1 Run this command in the **Terminal** tab to list Crossplane CRDs:
```bash
kubectl get crds | grep crossplane
```

You'll see several important CRDs that form the foundation of Crossplane:
- **providers.pkg.crossplane.io** - Manages cloud provider installations (AWS, GCP, Azure)
- **configurations.pkg.crossplane.io** - Packages that bundle multiple providers/compositions
- **compositions.apiextensions.crossplane.io** - Templates that define how to create infrastructure
- **compositeresourcedefinitions.apiextensions.crossplane.io** - Define custom APIs for your platform
- **functions.pkg.crossplane.io** - Composition functions for advanced logic
- **locks.pkg.crossplane.io** - Handles resource locking and dependencies

5.2 Run this command in the **Terminal** tab to check if any providers are installed:
```bash
kubectl get providers
```

You should see:
```
No resources found
```

This is expected since we haven't installed any providers yet.

5.3 Run this command in the **Terminal** tab to check if any configurations are installed:
```bash
kubectl get configurations
```

You should see:
```
No resources found
```

This is also expected at this stage.



## Success Criteria

✅ Crossplane Helm repository added successfully  
✅ Crossplane installed with optimized values  
✅ All Crossplane pods are Running  
✅ Crossplane CLI installed and functional  
✅ Crossplane CRDs are available  
✅ Crossplane package manager is ready  


## Troubleshooting

If you encounter issues:

- **Pods not starting**: Check resource limits with `minikube status`
- **ImagePullBackOff**: Verify internet connectivity - minikube should handle this automatically
- **RBAC errors**: minikube provides cluster-admin by default, so this shouldn't occur

Check logs for detailed error information by running these commands in the **Terminal** tab:
```bash
kubectl logs -n crossplane-system -l app=crossplane
minikube logs
```

## Platform Engineering Notes

The minikube configuration includes:
- **Resource management**: Optimized for single-node development environment
- **Security**: Production security patterns even in development
- **Monitoring**: Metrics enabled for observability learning
- **Development features**: Composition revisions and realtime compositions
- **Simplified deployment**: No need for high availability in learning environment

This setup gives you production-grade Crossplane patterns in a fast, reliable development environment perfect for learning platform engineering concepts.

**Learn More:**
- [Crossplane Installation Guide](https://docs.crossplane.io/v1.20/software/install/)
- [Crossplane Configuration Reference](https://docs.crossplane.io/v1.20/software/install/#configuration)
- [Helm Charts Documentation](https://docs.crossplane.io/v1.20/software/install/#helm-chart)

## Next Steps

With Crossplane installed on minikube, you'll next set up RBAC for platform and development teams to enable secure multi-tenant access patterns that mirror production environments.

**Related Documentation:**
- [Crossplane RBAC Guide](https://docs.crossplane.io/v1.20/concepts/rbac/)
- [Platform Engineering with Crossplane](https://docs.crossplane.io/v1.20/concepts/platform/) 