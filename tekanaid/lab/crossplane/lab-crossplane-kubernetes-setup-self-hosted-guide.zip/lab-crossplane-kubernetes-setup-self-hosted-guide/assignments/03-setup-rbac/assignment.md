
In this task, you'll set up RBAC to enable secure multi-tenant access to your Crossplane platform, creating the foundation for platform engineering workflows.

## Step 1: Create Platform Engineering Roles

Create roles that define permissions for platform engineering teams.

1.1 Create the platform administrator role. Create this file in the **Manifests** tab and name it `platform-admin-role.yaml`:

**Note:** For more information on Crossplane RBAC, see the [Crossplane RBAC Guide](https://docs.crossplane.io/v1.20/concepts/rbac/).

```yaml
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: platform-admin
rules:
# Full Crossplane permissions
- apiGroups: ["*"]
  resources: ["*"]
  verbs: ["*"]
  resourceNames: []
# Kubernetes cluster administration
- apiGroups: [""]
  resources: ["*"]
  verbs: ["*"]
- apiGroups: ["apps", "extensions"]
  resources: ["*"]
  verbs: ["*"]
- apiGroups: ["networking.k8s.io"]
  resources: ["*"]
  verbs: ["*"]
```

1.2 Create platform operator role (limited admin). Create this file in the **Manifests** tab and name it `platform-operator-role.yaml`:

```yaml
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: platform-operator
rules:
# Crossplane management permissions
- apiGroups: ["pkg.crossplane.io"]
  resources: ["providers", "configurations", "configurationrevisions"]
  verbs: ["get", "list", "watch", "create", "update", "patch"]
- apiGroups: ["apiextensions.crossplane.io"]
  resources: ["*"]
  verbs: ["get", "list", "watch", "create", "update", "patch"]
# Read-only for infrastructure resources
- apiGroups: ["*"]
  resources: ["*"]
  verbs: ["get", "list", "watch"]
  resourceNames: []
# Namespace management for teams
- apiGroups: [""]
  resources: ["namespaces"]
  verbs: ["get", "list", "watch", "create", "update", "patch"]
```

## Step 2: Create Developer Team Roles

Create roles for development teams using the platform:

2.1 Create a developer role for using Crossplane resources. Create this file in the **Manifests** tab and name it `crossplane-developer-role.yaml`:

```yaml
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: crossplane-developer
rules:
# Claims and composite resources (what developers interact with)
- apiGroups: ["apiextensions.crossplane.io"]
  resources: ["*"]
  verbs: ["get", "list", "watch", "create", "update", "patch", "delete"]
# Read-only access to system information
- apiGroups: [""]
  resources: ["nodes", "namespaces"]
  verbs: ["get", "list", "watch"]
```

2.2 Create a namespace-scoped role for team isolation. Create this file in the **Manifests** tab and name it `backend-team-developer-role.yaml`:

```yaml
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  namespace: backend-team
  name: backend-team-developer
rules:
# Full access within team namespace
- apiGroups: [""]
  resources: ["*"]
  verbs: ["*"]
- apiGroups: ["apps", "extensions"]
  resources: ["*"]
  verbs: ["*"]
# Crossplane claims in namespace
- apiGroups: ["*"]
  resources: ["*"]
  verbs: ["*"]
  resourceNames: []
```

## Step 3: Apply RBAC Roles

Apply the roles you created to the cluster:

3.1 Run these commands in the **Terminal** tab to apply all the role manifests:
```bash
kubectl apply -f /root/crossplane/manifests/platform-admin-role.yaml
```

```bash
kubectl apply -f /root/crossplane/manifests/platform-operator-role.yaml
```

```bash
kubectl apply -f /root/crossplane/manifests/crossplane-developer-role.yaml
```

```bash
kubectl apply -f /root/crossplane/manifests/backend-team-developer-role.yaml
```

Each command should show the respective role was created.

3.2 Verify the cluster roles were created:
```bash
kubectl get clusterroles | grep -E "(platform-admin|platform-operator|crossplane-developer)"
```

You should see all three cluster roles listed.

3.3 Verify the namespace role was created:
```bash
kubectl get roles -n backend-team
```

You should see the `backend-team-developer` role listed.

## Step 4: Create Service Accounts

Create service accounts for different personas:

4.1 Run these commands in the **Terminal** tab to create platform team service accounts:
```bash
kubectl create serviceaccount platform-admin -n platform-team
```

```bash
kubectl create serviceaccount platform-operator -n platform-team
```

You should see confirmation that each service account was created.

4.2 Run these commands in the **Terminal** tab to create developer team service accounts:
```bash
kubectl create serviceaccount backend-developer -n backend-team
```

```bash
kubectl create serviceaccount frontend-developer -n frontend-team
```

You should see confirmation that each service account was created.

4.3 Run this command in the **Terminal** tab to verify platform team service accounts:
```bash
kubectl get serviceaccounts -n platform-team
```

You should see `platform-admin` and `platform-operator` service accounts listed.

4.4 Run this command in the **Terminal** tab to verify backend team service account:
```bash
kubectl get serviceaccounts -n backend-team
```

You should see the `backend-developer` service account listed.

4.5 Run this command in the **Terminal** tab to verify frontend team service account:
```bash
kubectl get serviceaccounts -n frontend-team
```

You should see the `frontend-developer` service account listed.

## Step 5: Create Role Bindings

Bind the roles to service accounts to demonstrate multi-tenant patterns:

5.1 Create role bindings. Create this file in the **Manifests** tab and name it `role-bindings.yaml`:

```yaml
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: platform-admin-binding
subjects:
- kind: ServiceAccount
  name: platform-admin
  namespace: platform-team
roleRef:
  kind: ClusterRole
  name: platform-admin
  apiGroup: rbac.authorization.k8s.io
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: platform-operator-binding
subjects:
- kind: ServiceAccount
  name: platform-operator
  namespace: platform-team
roleRef:
  kind: ClusterRole
  name: platform-operator
  apiGroup: rbac.authorization.k8s.io
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: backend-developer-binding
subjects:
- kind: ServiceAccount
  name: backend-developer
  namespace: backend-team
roleRef:
  kind: ClusterRole
  name: crossplane-developer
  apiGroup: rbac.authorization.k8s.io
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: backend-team-binding
  namespace: backend-team
subjects:
- kind: ServiceAccount
  name: backend-developer
  namespace: backend-team
roleRef:
  kind: Role
  name: backend-team-developer
  apiGroup: rbac.authorization.k8s.io
```

5.2 Apply the role bindings to the cluster:
```bash
kubectl apply -f /root/crossplane/manifests/role-bindings.yaml
```

You should see confirmation that all four bindings were created.

5.3 Verify the cluster role bindings were created:
```bash
kubectl get clusterrolebindings | grep -E "(platform-admin|platform-operator|backend-developer)"
```

You should see three cluster role bindings listed.

5.4 Verify the namespace role binding was created:
```bash
kubectl get rolebindings -n backend-team
```

You should see the `backend-team-binding` role binding listed.

## Step 6: Test RBAC Configuration

Test the RBAC setup by impersonating different service accounts. The `--as` flag simulates being that service account:

6.1 Run this command in the **Terminal** tab to test platform admin has full cluster access:
```bash
kubectl auth can-i "*" "*" --as=system:serviceaccount:platform-team:platform-admin
```

You should see:
```
yes
```

This confirms platform admins can do everything in the cluster.

6.2 Run this command in the **Terminal** tab to test platform operator can manage Crossplane providers:
```bash
kubectl auth can-i create providers --as=system:serviceaccount:platform-team:platform-operator
```

You should see:
```
yes
```

**Note**: Any warning about providers not being namespace-scoped is normal - providers are cluster-wide resources.

6.3 Run this command in the **Terminal** tab to test platform operator CANNOT delete nodes:
```bash
kubectl auth can-i delete nodes --as=system:serviceaccount:platform-team:platform-operator
```

You should see:
```
no
```

This confirms platform operators have limited cluster access.

7.4 Run this command in the **Terminal** tab to test developer can create pods in their own namespace:
```bash
kubectl auth can-i create pods -n backend-team --as=system:serviceaccount:backend-team:backend-developer
```

You should see:
```
yes
```

This confirms developers have full access within their team's namespace.

7.5 Run this command in the **Terminal** tab to test developer CANNOT create Crossplane providers:
```bash
kubectl auth can-i create providers --as=system:serviceaccount:backend-team:backend-developer
```

You should see:
```
no
```

This confirms only the platform team can manage Crossplane infrastructure.

7.6 Run this command in the **Terminal** tab to test developer CANNOT access other team's namespace:
```bash
kubectl auth can-i create pods -n frontend-team --as=system:serviceaccount:backend-team:backend-developer
```

You should see:
```
no
```

This confirms teams are isolated and can't access each other's namespaces.


## Success Criteria

✅ Platform engineering roles created successfully  
✅ Developer team roles configured  
✅ Service accounts created for each persona  
✅ Role bindings established correctly  
✅ RBAC permissions tested and verified  
✅ Isolation between teams confirmed  


## Troubleshooting

If you encounter RBAC issues:

- **Permission denied**: Check role bindings and service account names
- **Roles not found**: Verify role creation with `kubectl get roles,clusterroles`
- **Service account issues**: Ensure service accounts exist in correct namespaces
- **Binding problems**: Check binding syntax and references

Debug RBAC by running these commands in the **Terminal** tab:
```bash
kubectl auth can-i --list --as=system:serviceaccount:NAMESPACE:SERVICEACCOUNT
kubectl get rolebindings,clusterrolebindings -o wide
kubectl describe role ROLE_NAME
```

## Platform Engineering Notes

This RBAC configuration demonstrates:
- **Multi-tenancy**: Teams isolated by namespace and permissions
- **Role hierarchy**: Clear separation between platform and application teams
- **Security boundaries**: Developers can't access platform infrastructure
- **Scalability**: Pattern can extend to many teams and environments
- **Compliance**: Audit trails and least-privilege access

In production, you'd integrate with enterprise identity systems, but this pattern shows the essential security model for platform engineering.

**Learn More:**
- [Crossplane RBAC Guide](https://docs.crossplane.io/v1.20/concepts/rbac/)
- [Kubernetes RBAC Documentation](https://kubernetes.io/docs/reference/access-authn-authz/rbac/)
- [Platform Engineering Security](https://docs.crossplane.io/v1.20/concepts/platform/)

## Next Steps

With RBAC configured, your Crossplane platform foundation is complete! You can now:
- Install cloud providers securely
- Create compositions with appropriate permissions
- Enable teams to consume infrastructure via claims
- Maintain security boundaries between platform and applications

This completes your Crossplane platform setup with minikube - fast, secure, and ready for platform engineering!

## Summary

You have successfully:
- ✅ Set up a Kubernetes cluster with minikube optimized for platform engineering
- ✅ Installed Crossplane with production-ready configuration
- ✅ Configured RBAC for multi-tenant platform engineering
- ✅ Created roles and permissions for platform and developer teams
- ✅ Tested the security model with different personas

Your Crossplane platform is now ready for:
- Installing cloud providers (AWS, GCP, Azure)
- Creating infrastructure compositions
- Enabling self-service infrastructure for development teams
- Building a complete platform engineering solution

**Related Documentation:**
- [Crossplane Providers](https://docs.crossplane.io/v1.20/concepts/providers/)
- [Crossplane Compositions](https://docs.crossplane.io/v1.20/concepts/compositions/)
- [Platform Engineering Guide](https://docs.crossplane.io/v1.20/concepts/platform/)
