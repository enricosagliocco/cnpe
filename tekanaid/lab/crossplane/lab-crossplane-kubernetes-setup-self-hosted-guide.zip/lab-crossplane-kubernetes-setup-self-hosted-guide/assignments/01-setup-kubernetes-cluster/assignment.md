
In this task, you'll start a Kubernetes cluster using minikube, which provides a perfect environment for learning Crossplane platform engineering concepts.

## Step 1: Start minikube Cluster

1.1 Start a minikube cluster optimized for Crossplane, this takes about a minute. Run the following command in the **Terminal** tab:

**Note:** For more information on minikube, see the [minikube documentation](https://minikube.sigs.k8s.io/docs/start/).

```bash
minikube start \
  --cpus=2 \
  --memory=2500 \
  --kubernetes-version=v1.32.0 \
  --driver=docker \
  --force
```

1.2 Verify that the cluster is running by running this command in the **Terminal** tab:
```bash
kubectl cluster-info
```

You should see output similar to:
```
Kubernetes control plane is running at https://192.168.49.2:8443
CoreDNS is running at https://192.168.49.2:8443/api/v1/namespaces/kube-system/services/kube-dns:dns/proxy
```

## Step 2: Verify Cluster Health

Check that your cluster is ready and all system pods are running:

2.1 Check node status by running this command in the **Terminal** tab:
```bash
kubectl get nodes
```

You should see output similar to:
```
NAME       STATUS   ROLES           AGE   VERSION
minikube   Ready    control-plane   2m    v1.32.0
```

**Note:** The Kubernetes version may vary (v1.30.0 or higher) depending on your minikube installation.

2.2 Check system pods by running this command in the **Terminal** tab:
```bash
kubectl get pods -n kube-system
```

All pods should show `Running` status. You should see core components like:
- coredns
- etcd
- kube-apiserver
- kube-controller-manager
- kube-proxy
- kube-scheduler
- storage-provisioner

2.3 Verify you can create resources by running this command in the **Terminal** tab:
```bash
kubectl auth can-i create pods
```

You should see:
```
yes
```

## Step 3: Create Namespaces for Platform Engineering

Set up namespaces for organized platform management:

3.1 Create Crossplane system namespace by running this command in the **Terminal** tab:
```bash
kubectl create namespace crossplane-system
```

You should see:
```
namespace/crossplane-system created
```

3.2 Create namespace for platform team by running this command in the **Terminal** tab:
```bash
kubectl create namespace platform-team
```

You should see:
```
namespace/platform-team created
```

3.3 Create namespaces for development teams by running these commands in the **Terminal** tab:
```bash
kubectl create namespace backend-team
```

```bash
kubectl create namespace frontend-team
```

You should see each namespace created successfully.

3.4 Verify namespaces by running this command in the **Terminal** tab:
```bash
kubectl get namespaces
```

You should see all the namespaces you created, including:
- `crossplane-system`
- `platform-team`
- `backend-team`
- `frontend-team`
- Default Kubernetes namespaces (`default`, `kube-system`, `kube-public`, `kube-node-lease`)

3.5 Check cluster access by running this command in the **Terminal** tab:
```bash
kubectl get all --all-namespaces
```

This should show all resources across all namespaces without errors.


## Success Criteria

✅ minikube cluster started successfully  
✅ All system pods in `kube-system` namespace are Running  
✅ Node shows Ready status  
✅ Required namespaces created  
✅ kubectl commands work without errors  


## Troubleshooting

If you encounter issues:

- **minikube won't start**: Try `minikube delete` and start again
- **Resource issues**: The lab uses `--memory=2500` to fit in VM constraints
- **Root privilege warning**: Use `--force` flag as shown (normal in lab environment)
- **Memory allocation warning**: This is expected in the lab VM and can be safely ignored

Debug with:
```bash
minikube status
minikube logs
```

## Why minikube for Platform Engineering?

minikube is perfect for learning Crossplane because of:
- **Fast startup**: Cluster ready in under 2 minutes
- **Reliable**: Consistent environment across different systems
- **Resource efficient**: Runs well on modest hardware
- **Feature complete**: Full Kubernetes API for Crossplane
- **Easy reset**: `minikube delete` for clean slate

For production platform engineering, you'd use managed Kubernetes services (EKS, GKE, AKS) or enterprise distributions, but minikube lets us focus on Crossplane concepts without cluster management complexity.

**Learn More:**
- [Crossplane Installation Guide](https://docs.crossplane.io/v1.20/software/install/)
- [Kubernetes Platform Engineering](https://docs.crossplane.io/v1.20/concepts/platform/)
- [minikube Documentation](https://minikube.sigs.k8s.io/docs/start/)

## Next Steps

With your Kubernetes cluster ready, you'll next install Helm and prepare for Crossplane installation. The fast, reliable minikube environment will let you focus on learning platform engineering concepts rather than cluster troubleshooting. 