# Setting Up Your Crossplane Platform — Self-Hosted Guide

This hands-on lab guides you through setting up a complete Crossplane platform engineering environment using minikube.

You'll learn to:
- Start a minikube cluster with optimal settings (2 CPUs, 2.5GB RAM, Kubernetes v1.32.0)
- Create namespaces for multi-tenant platform engineering (crossplane-system, platform-team, backend-team, frontend-team)
- Install Crossplane v1.20.0 using Helm with production-ready security settings
- Install and verify the Crossplane CLI for debugging and development
- Explore Crossplane CRDs (providers, configurations, compositions, XRDs, functions)
- Configure RBAC with multiple roles (platform-admin, platform-operator, crossplane-developer)
- Create service accounts and role bindings for secure multi-tenant access
- Test RBAC permissions to verify proper security boundaries between teams

This lab establishes the foundation for all subsequent Crossplane platform engineering activities using a fast, reliable minikube setup.

**Key Resources:**
- [Crossplane Documentation](https://docs.crossplane.io/)
- [Crossplane Installation Guide](https://docs.crossplane.io/v1.20/software/install/)
- [Crossplane RBAC Guide](https://docs.crossplane.io/v1.20/concepts/rbac/)
- [Platform Engineering with Crossplane](https://docs.crossplane.io/v1.20/concepts/platform/)

**Estimated Time:** 120 minutes
**Difficulty:** Beginner

## Prerequisites

- basic-kubernetes-knowledge
- helm-fundamentals
- linux-command-line

## VM Configuration

This lab uses the following VMs:

- **platform-cluster**: kubernetes-dev2025, medium

## How to Use This Guide

1. Set up your infrastructure (VMs or containers matching the configuration above)
2. Run the lab setup scripts from `scripts/lab/`
3. For each task (in order):
   a. Read the assignment in `assignments/{taskpath}/assignment.md`
   b. Run the task setup script from `scripts/tasks/{taskpath}/`
   c. Try to complete the assignment on your own
   d. If stuck, reference the solve script in `scripts/tasks/{taskpath}/`
4. When done, run the cleanup scripts from `scripts/lab/cleanup-*`

## Tasks

1. Start Kubernetes Cluster with minikube — `assignments/01-setup-kubernetes-cluster/`
2. Install Crossplane with Production Configuration — `assignments/02-install-crossplane/`
3. Configure Platform Engineering RBAC — `assignments/03-setup-rbac/`
