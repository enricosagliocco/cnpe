# CNPE Storage & Platform Architecture Hard

StorageClass/PV/PVC/StatefulSet lab.
