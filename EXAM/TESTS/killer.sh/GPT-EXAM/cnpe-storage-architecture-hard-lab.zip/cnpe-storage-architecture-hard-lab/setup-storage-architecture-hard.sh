#!/usr/bin/env bash
set -euo pipefail

PROFILE="${MINIKUBE_PROFILE:-cnpe-architecture-storage-hard}"
K8S_VERSION="${K8S_VERSION:-v1.33.0}"
CPUS="${MINIKUBE_CPUS:-4}"
MEMORY="${MINIKUBE_MEMORY:-10000}"
DRIVER="${MINIKUBE_DRIVER:-docker}"

CALLER_HOME="${HOME}"
if [ -n "${SUDO_USER:-}" ] && [ "${SUDO_USER}" != "root" ]; then
  CALLER_HOME="$(getent passwd "${SUDO_USER}" | cut -d: -f6)"
fi
LAB_DIR="${LAB_DIR:-${CALLER_HOME}/course/architecture-storage-hard}"

info(){ echo "[INFO] $*"; }
ok(){ echo "[OK] $*"; }
warn(){ echo "[WARN] $*"; }
die(){ echo "[ERR] $*"; exit 1; }
have(){ command -v "$1" >/dev/null 2>&1; }

for c in minikube kubectl curl; do have "$c" || die "$c non trovato"; done
mkdir -p "$LAB_DIR"

if ! minikube status -p "$PROFILE" >/dev/null 2>&1; then
  minikube start -p "$PROFILE" --driver="$DRIVER" --cpus="$CPUS" --memory="${MEMORY}mb" --disk-size=50g --kubernetes-version="$K8S_VERSION" --force
fi

export KUBECONFIG
KUBECONFIG="$(minikube kubeconfig --no-env -p "$PROFILE" 2>/dev/null || echo "$HOME/.kube/config")"
kubectl cluster-info >/dev/null

NS=arch-storage
if [ "${1:-}" = "--cleanup" ]; then
  kubectl delete ns "$NS" --ignore-not-found --timeout=120s 2>/dev/null || true
  kubectl delete pv arch-db-pv arch-rwx-pv --ignore-not-found 2>/dev/null || true
  kubectl delete sc arch-local arch-wrong --ignore-not-found 2>/dev/null || true
  rm -rf "$LAB_DIR"; ok cleanup; exit 0
fi
kubectl create ns "$NS" --dry-run=client -o yaml | kubectl apply -f -
NODE=$(kubectl get nodes -o jsonpath='{.items[0].metadata.name}')
minikube -p "$PROFILE" ssh -- "sudo mkdir -p /mnt/arch/db /mnt/arch/rwx && sudo chmod -R 777 /mnt/arch"
cat > "$LAB_DIR/00-storage-arch-broken.yaml" <<EOF
apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  name: arch-wrong
provisioner: kubernetes.io/no-provisioner
volumeBindingMode: Immediate
---
apiVersion: v1
kind: PersistentVolume
metadata:
  name: arch-db-pv
spec:
  capacity: {storage: 1Gi}
  accessModes: ["ReadWriteOnce"]
  storageClassName: arch-local
  persistentVolumeReclaimPolicy: Retain
  local: {path: /mnt/arch/db}
  nodeAffinity:
    required:
      nodeSelectorTerms:
      - matchExpressions:
        - key: kubernetes.io/hostname
          operator: In
          values: ["wrong-node"]
---
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: db-data
  namespace: arch-storage
spec:
  storageClassName: arch-local
  accessModes: ["ReadWriteOnce"]
  resources:
    requests: {storage: 1Gi}
---
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: db
  namespace: arch-storage
spec:
  serviceName: db
  replicas: 1
  selector:
    matchLabels: {app: db}
  template:
    metadata:
      labels: {app: db}
    spec:
      containers:
      - name: db
        image: postgres:16-alpine
        env:
        - {name: POSTGRES_PASSWORD, value: app}
        - {name: PGDATA, value: /wrong/path}
        volumeMounts:
        - {name: data, mountPath: /var/lib/postgresql/data}
  volumeClaimTemplates:
  - metadata: {name: data}
    spec:
      storageClassName: arch-local
      accessModes: ["ReadWriteOnce"]
      resources:
        requests: {storage: 1Gi}
---
apiVersion: v1
kind: Service
metadata:
  name: db-wrong
  namespace: arch-storage
spec:
  clusterIP: None
  selector: {app: db}
  ports:
  - port: 5432
EOF
kubectl apply -f "$LAB_DIR/00-storage-arch-broken.yaml"
cat > "$LAB_DIR/README.txt" <<EOF
Storage architecture hard. Node=$NODE
EOF
kubectl -n "$NS" get pod,sts,svc,pvc
kubectl get pv,sc
ok "storage architecture lab pronto"
