# CNPE Storage & Platform Architecture Hard

## Q1 — Stato iniziale storage.
## Q2 — Crea/correggi StorageClass arch-local WaitForFirstConsumer.
## Q3 — Correggi PV nodeAffinity.
## Q4 — PVC Pending diagnosis.
## Q5 — StatefulSet volumeClaimTemplate bind.
## Q6 — Headless Service db corretto.
## Q7 — PGDATA ConfigMap/patch senza riscrivere STS se possibile.
## Q8 — DB Running.
## Q9 — DNS db-0/db service.
## Q10 — Volume expansion scenario.
## Q11 — AccessMode RWO vs RWX report.
## Q12 — ReclaimPolicy report.
## Q13 — Backup Job su PVC.
## Q14 — Restore Job simulato.
## Q15 — Topology aware storage report.
## Q16 — Cost/right sizing report richieste storage.
## Q17 — Multi-tenant quota storage.
## Q18 — PVC resize se supportato.
## Q19 — Incident RCA.
## Q20 — Final architecture report.