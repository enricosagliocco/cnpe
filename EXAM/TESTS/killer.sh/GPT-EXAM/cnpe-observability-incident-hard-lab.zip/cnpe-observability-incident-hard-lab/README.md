# CNPE Observability & Incident Response Hard

Esegui setup e poi le 20 domande.
