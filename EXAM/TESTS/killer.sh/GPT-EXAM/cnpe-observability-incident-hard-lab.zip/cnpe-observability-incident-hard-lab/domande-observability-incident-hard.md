# CNPE Observability & Incident Response Hard

## Q1 — Stato iniziale Prometheus/Grafana
Salva pod, svc, CRD monitoring in `/course/observability-hard/q1-status.txt`.
## Q2 — ServiceMonitor broken
Correggi selector, labels e endpoint del ServiceMonitor `metrics-app`.
## Q3 — Prometheus targets
Verifica che il target app sia UP e salva screenshot/testo query.
## Q4 — PromQL
Esegui query `up` e `http_requests_total` se presente; salva risultato.
## Q5 — Alert rule
Correggi PrometheusRule `MetricsAppDown` con label/job corretti.
## Q6 — Grafana datasource
Verifica datasource Prometheus e salva config.
## Q7 — Grafana dashboard
Crea/importa dashboard minimale per target up.
## Q8 — Loki install/status
Verifica Loki e documenta eventuali problemi risorse.
## Q9 — Logging app
Crea pod che produce log e prepara query Loki.
## Q10 — LogQL
Salva query per filtrare namespace apps.
## Q11 — OTEL collector
Correggi pipeline metrics con exporter prometheus.
## Q12 — ServiceMonitor OTEL
Crea ServiceMonitor per endpoint 8889 collector.
## Q13 — Trace pipeline
Verifica pipeline traces con exporter debug.
## Q14 — Incident target down
Rompi e ripristina selector service, documenta RCA.
## Q15 — Alert firing
Simula target down e cattura alert pending/firing.
## Q16 — Alert recovery
Ripristina target e salva stato.
## Q17 — Resource efficiency
Calcola richieste/limiti principali monitoring.
## Q18 — Runbook
Scrivi runbook per target Prometheus down.
## Q19 — Cleanup vecchi test
Rimuovi pod temporanei e salva stato.
## Q20 — Final report
Crea `/course/observability-hard/final-report.txt` con Prometheus, alert, logs, OTEL, RCA.