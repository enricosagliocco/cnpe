#!/usr/bin/env bash
set -euo pipefail

PROFILE="${MINIKUBE_PROFILE:-cnpe-observability-hard}"
K8S_VERSION="${K8S_VERSION:-v1.33.0}"
CPUS="${MINIKUBE_CPUS:-4}"
MEMORY="${MINIKUBE_MEMORY:-10000}"
DRIVER="${MINIKUBE_DRIVER:-docker}"

CALLER_HOME="${HOME}"
if [ -n "${SUDO_USER:-}" ] && [ "${SUDO_USER}" != "root" ]; then
  CALLER_HOME="$(getent passwd "${SUDO_USER}" | cut -d: -f6)"
fi
LAB_DIR="${LAB_DIR:-${CALLER_HOME}/course/observability-hard}"

info(){ echo "[INFO] $*"; }
ok(){ echo "[OK] $*"; }
warn(){ echo "[WARN] $*"; }
die(){ echo "[ERR] $*"; exit 1; }
have(){ command -v "$1" >/dev/null 2>&1; }

for c in minikube kubectl curl; do have "$c" || die "$c non trovato"; done
mkdir -p "$LAB_DIR"

if ! minikube status -p "$PROFILE" >/dev/null 2>&1; then
  minikube start -p "$PROFILE" --driver="$DRIVER" --cpus="$CPUS" --memory="${MEMORY}mb" --disk-size=50g --kubernetes-version="$K8S_VERSION" --force
fi

export KUBECONFIG
KUBECONFIG="$(minikube kubeconfig --no-env -p "$PROFILE" 2>/dev/null || echo "$HOME/.kube/config")"
kubectl cluster-info >/dev/null

if [ "${1:-}" = "--cleanup" ]; then
  kubectl delete ns monitoring apps logs tracing --ignore-not-found --timeout=180s 2>/dev/null || true
  rm -rf "$LAB_DIR"; ok cleanup; exit 0
fi
for ns in monitoring apps logs tracing; do kubectl create ns "$ns" --dry-run=client -o yaml | kubectl apply -f -; done

info "install kube-prometheus-stack"
helm version >/dev/null 2>&1 || die "helm richiesto"
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts >/dev/null 2>&1 || true
helm repo add grafana https://grafana.github.io/helm-charts >/dev/null 2>&1 || true
helm repo update >/dev/null
helm upgrade --install kps prometheus-community/kube-prometheus-stack -n monitoring --wait --timeout=300s \
  --set prometheus.prometheusSpec.serviceMonitorSelectorNilUsesHelmValues=false \
  --set prometheus.prometheusSpec.podMonitorSelectorNilUsesHelmValues=false \
  --set grafana.adminPassword=admin

info "install loki single binary"
helm upgrade --install loki grafana/loki -n logs --wait --timeout=300s \
  --set deploymentMode=SingleBinary \
  --set loki.auth_enabled=false \
  --set loki.commonConfig.replication_factor=1 \
  --set singleBinary.replicas=1 \
  --set minio.enabled=false || warn "loki helm può richiedere risorse; continuando"

cat > "$LAB_DIR/00-apps-metrics-broken.yaml" <<'YAML'
apiVersion: apps/v1
kind: Deployment
metadata:
  name: metrics-app
  namespace: apps
  labels:
    app: metrics-app
spec:
  replicas: 1
  selector:
    matchLabels:
      app: metrics-app
  template:
    metadata:
      labels:
        app: metrics-app
    spec:
      containers:
      - name: app
        image: prom/prometheus-example-app:v0.4.2
        ports:
        - name: web
          containerPort: 8080
---
apiVersion: v1
kind: Service
metadata:
  name: metrics-app
  namespace: apps
  labels:
    app: metrics-app
spec:
  selector:
    app: metrics-app
  ports:
  - name: http
    port: 8080
    targetPort: web
---
apiVersion: monitoring.coreos.com/v1
kind: ServiceMonitor
metadata:
  name: metrics-app
  namespace: monitoring
  labels:
    release: wrong
spec:
  namespaceSelector:
    matchNames:
    - apps
  selector:
    matchLabels:
      app: wrong-app
  endpoints:
  - port: metrics
    interval: 15s
YAML

cat > "$LAB_DIR/01-alerts-broken.yaml" <<'YAML'
apiVersion: monitoring.coreos.com/v1
kind: PrometheusRule
metadata:
  name: cnpe-alerts
  namespace: monitoring
  labels:
    release: kps
spec:
  groups:
  - name: cnpe.rules
    rules:
    - alert: MetricsAppDown
      expr: up{job="metrics-app"} == 0
      for: 1m
      labels:
        severity: warning
      annotations:
        summary: metrics app target down
YAML

cat > "$LAB_DIR/02-otel-jaeger-broken.yaml" <<'YAML'
apiVersion: apps/v1
kind: Deployment
metadata:
  name: otel-collector
  namespace: tracing
spec:
  replicas: 1
  selector:
    matchLabels:
      app: otel-collector
  template:
    metadata:
      labels:
        app: otel-collector
    spec:
      containers:
      - name: collector
        image: otel/opentelemetry-collector-contrib:0.104.0
        args: ["--config=/conf/config.yaml"]
        ports:
        - containerPort: 4317
        - containerPort: 4318
        - containerPort: 8889
        volumeMounts:
        - name: config
          mountPath: /conf
      volumes:
      - name: config
        configMap:
          name: otel-config
---
apiVersion: v1
kind: ConfigMap
metadata:
  name: otel-config
  namespace: tracing
data:
  config.yaml: |
    receivers:
      otlp:
        protocols:
          grpc:
          http:
    exporters:
      prometheus:
        endpoint: "0.0.0.0:8889"
      debug: {}
    service:
      pipelines:
        traces:
          receivers: [otlp]
          exporters: [debug]
        metrics:
          receivers: [otlp]
          # BUG: manca exporter prometheus
          exporters: [debug]
---
apiVersion: v1
kind: Service
metadata:
  name: otel-collector
  namespace: tracing
  labels:
    app: otel-collector
spec:
  selector:
    app: otel-collector
  ports:
  - name: otlp-grpc
    port: 4317
  - name: otlp-http
    port: 4318
  - name: prom
    port: 8889
YAML

kubectl apply -f "$LAB_DIR/00-apps-metrics-broken.yaml"
kubectl apply -f "$LAB_DIR/01-alerts-broken.yaml"
kubectl apply -f "$LAB_DIR/02-otel-jaeger-broken.yaml"

cat > "$LAB_DIR/README.txt" <<EOF
CNPE Observability hard
Namespaces: monitoring apps logs tracing
Grafana: kubectl -n monitoring port-forward svc/kps-grafana 3000:80 admin/admin
Prometheus: kubectl -n monitoring port-forward svc/kps-kube-prometheus-stack-prometheus 9090:9090
Files: $LAB_DIR
EOF
kubectl -n monitoring get servicemonitor,prometheusrule
kubectl -n apps get deploy,svc
ok "observability lab pronto"
