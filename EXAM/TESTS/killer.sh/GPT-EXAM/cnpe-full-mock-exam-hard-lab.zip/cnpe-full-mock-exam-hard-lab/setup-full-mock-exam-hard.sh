#!/usr/bin/env bash
set -euo pipefail

PROFILE="${MINIKUBE_PROFILE:-cnpe-full-mock-hard}"
K8S_VERSION="${K8S_VERSION:-v1.33.0}"
CPUS="${MINIKUBE_CPUS:-4}"
MEMORY="${MINIKUBE_MEMORY:-10000}"
DRIVER="${MINIKUBE_DRIVER:-docker}"

CALLER_HOME="${HOME}"
if [ -n "${SUDO_USER:-}" ] && [ "${SUDO_USER}" != "root" ]; then
  CALLER_HOME="$(getent passwd "${SUDO_USER}" | cut -d: -f6)"
fi
LAB_DIR="${LAB_DIR:-${CALLER_HOME}/course/full-mock-hard}"

info(){ echo "[INFO] $*"; }
ok(){ echo "[OK] $*"; }
warn(){ echo "[WARN] $*"; }
die(){ echo "[ERR] $*"; exit 1; }
have(){ command -v "$1" >/dev/null 2>&1; }

for c in minikube kubectl curl; do have "$c" || die "$c non trovato"; done
mkdir -p "$LAB_DIR"

if ! minikube status -p "$PROFILE" >/dev/null 2>&1; then
  minikube start -p "$PROFILE" --driver="$DRIVER" --cpus="$CPUS" --memory="${MEMORY}mb" --disk-size=50g --kubernetes-version="$K8S_VERSION" --force
fi

export KUBECONFIG
KUBECONFIG="$(minikube kubeconfig --no-env -p "$PROFILE" 2>/dev/null || echo "$HOME/.kube/config")"
kubectl cluster-info >/dev/null

if [ "${1:-}" = "--cleanup" ]; then
  kubectl delete ns mock-gitops mock-platform mock-security mock-obs mock-arch --ignore-not-found --timeout=180s 2>/dev/null || true
  kubectl delete crd mockservices.platform.cnpe.io --ignore-not-found 2>/dev/null || true
  rm -rf "$LAB_DIR"; ok cleanup; exit 0
fi
for ns in mock-gitops mock-platform mock-security mock-obs mock-arch; do kubectl create ns "$ns" --dry-run=client -o yaml | kubectl apply -f -; done
cat > "$LAB_DIR/00-full-mock.yaml" <<'YAML'
apiVersion: apps/v1
kind: Deployment
metadata:
  name: broken-web
  namespace: mock-gitops
spec:
  replicas: 1
  selector:
    matchLabels: {app: broken-web}
  template:
    metadata:
      labels: {app: broken-web}
    spec:
      containers:
      - name: web
        image: nginx:latest
---
apiVersion: apiextensions.k8s.io/v1
kind: CustomResourceDefinition
metadata:
  name: mockservices.platform.cnpe.io
spec:
  group: platform.cnpe.io
  scope: Namespaced
  names:
    plural: mockservices
    singular: mockservice
    kind: MockService
  versions:
  - name: v1alpha1
    served: true
    storage: true
    schema:
      openAPIV3Schema:
        type: object
        properties:
          spec:
            type: object
            properties:
              image: {type: string}
              replicas: {type: integer}
          status:
            type: object
            properties:
              phase: {type: string}
    subresources: {status: {}}
---
apiVersion: platform.cnpe.io/v1alpha1
kind: MockService
metadata:
  name: api
  namespace: mock-platform
spec:
  image: nginx:latest
  replicas: 1
---
apiVersion: v1
kind: ServiceAccount
metadata:
  name: viewer
  namespace: mock-security
---
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: deny-ingress-only
  namespace: mock-security
spec:
  podSelector: {}
  policyTypes: ["Ingress"]
---
apiVersion: v1
kind: ConfigMap
metadata:
  name: prometheus-config
  namespace: mock-obs
data:
  scrape: "wrong-selector"
---
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: data
  namespace: mock-arch
spec:
  storageClassName: missing-sc
  accessModes: ["ReadWriteOnce"]
  resources:
    requests: {storage: 1Gi}
YAML
kubectl apply -f "$LAB_DIR/00-full-mock.yaml"
cat > "$LAB_DIR/README.txt" <<EOF
Full CNPE mock: namespaces mock-gitops mock-platform mock-security mock-obs mock-arch
EOF
kubectl get ns mock-gitops mock-platform mock-security mock-obs mock-arch
ok "full mock lab pronto"
