# CNPE Full Mock Exam Hard

## Q1 — GitOps-style app: fix image/tag and labels.
## Q2 — Create Kustomization for broken-web.
## Q3 — Create ArgoCD Application manifest (do not install ArgoCD required).
## Q4 — Progressive delivery: convert Deployment to Rollout manifest.
## Q5 — CRD: add spec.size to MockService.
## Q6 — Create reconciler Job for MockService.
## Q7 — Update MockService status.
## Q8 — Create DatabaseClaim-style Secret/Service.
## Q9 — RBAC least privilege viewer pods.
## Q10 — NetworkPolicy deny ingress+egress.
## Q11 — Gatekeeper manifest required labels.
## Q12 — Tekton security gate manifest.
## Q13 — Prometheus scrape config fix.
## Q14 — Create ServiceMonitor manifest.
## Q15 — Loki/LogQL query report.
## Q16 — OTEL collector ConfigMap manifest.
## Q17 — StorageClass for missing-sc.
## Q18 — PV/PVC bind scenario.
## Q19 — Incident report across domains.
## Q20 — Final 120-min mock report.