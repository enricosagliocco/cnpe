# CNPE Full Mock Exam Hard

Mixed 20 domande, lightweight.
