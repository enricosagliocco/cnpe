# CNPE Crossplane & Self-Service Hard

## Q1 — Ispezione Crossplane e CRD
Salva stato crossplane-system e AppClaim.
## Q2 — CRD schema
Aggiungi `spec.size` enum small/medium/large.
## Q3 — Claim remediation
Correggi AppClaim portal: immagine non latest e size small.
## Q4 — RBAC status
Aggiungi permessi appclaims/status patch/update.
## Q5 — Reconciler Deployment
Correggi Job per creare Deployment con limits cpu/mem.
## Q6 — Reconciler Service
Estendi Job per creare Service se expose=true.
## Q7 — Status
Aggiorna status phase=Ready endpoint=<svc>.
## Q8 — Rilancio reconcile
Rilancia Job e verifica Deployment/Service/status.
## Q9 — Composition selector
Correggi ConfigMap composition selector da tier=wrong.
## Q10 — PatchSet
Documenta e correggi patchSet per resource limits.
## Q11 — Transform
Correggi trasformazione replicas int.
## Q12 — ProviderConfig concept
Crea ConfigMap ProviderConfig simulata valida.
## Q13 — Helm provider concept
Crea manifest HelmRelease simulato Headlamp.
## Q14 — Keycloak selfservice
Crea AppClaim keycloak-like con replicas 1.
## Q15 — Secret generation
Crea Secret connection portal-conn e referenzialo in status/report.
## Q16 — Claim migration
Cambia portal replicas 2 e riconcilia.
## Q17 — Composition revision
Documenta cambio versione composizione.
## Q18 — Operator pattern
Scrivi runbook controller/CRD/status.
## Q19 — Audit
Report su CRD, claims, controller, RBAC.
## Q20 — Final report
Crea final-report con self-service API completa.