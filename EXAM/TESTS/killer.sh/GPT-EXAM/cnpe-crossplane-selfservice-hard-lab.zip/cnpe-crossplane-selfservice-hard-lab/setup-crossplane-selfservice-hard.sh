#!/usr/bin/env bash
set -euo pipefail

PROFILE="${MINIKUBE_PROFILE:-cnpe-crossplane-selfservice-hard}"
K8S_VERSION="${K8S_VERSION:-v1.33.0}"
CPUS="${MINIKUBE_CPUS:-4}"
MEMORY="${MINIKUBE_MEMORY:-10000}"
DRIVER="${MINIKUBE_DRIVER:-docker}"

CALLER_HOME="${HOME}"
if [ -n "${SUDO_USER:-}" ] && [ "${SUDO_USER}" != "root" ]; then
  CALLER_HOME="$(getent passwd "${SUDO_USER}" | cut -d: -f6)"
fi
LAB_DIR="${LAB_DIR:-${CALLER_HOME}/course/crossplane-selfservice-hard}"

info(){ echo "[INFO] $*"; }
ok(){ echo "[OK] $*"; }
warn(){ echo "[WARN] $*"; }
die(){ echo "[ERR] $*"; exit 1; }
have(){ command -v "$1" >/dev/null 2>&1; }

for c in minikube kubectl curl; do have "$c" || die "$c non trovato"; done
mkdir -p "$LAB_DIR"

if ! minikube status -p "$PROFILE" >/dev/null 2>&1; then
  minikube start -p "$PROFILE" --driver="$DRIVER" --cpus="$CPUS" --memory="${MEMORY}mb" --disk-size=50g --kubernetes-version="$K8S_VERSION" --force
fi

export KUBECONFIG
KUBECONFIG="$(minikube kubeconfig --no-env -p "$PROFILE" 2>/dev/null || echo "$HOME/.kube/config")"
kubectl cluster-info >/dev/null

if [ "${1:-}" = "--cleanup" ]; then
  kubectl delete ns crossplane-system platform tenants --ignore-not-found --timeout=180s 2>/dev/null || true
  kubectl delete crd xapps.platform.cnpe.io appclaims.platform.cnpe.io --ignore-not-found 2>/dev/null || true
  rm -rf "$LAB_DIR"; ok cleanup; exit 0
fi
helm version >/dev/null 2>&1 || die "helm richiesto"
helm repo add crossplane-stable https://charts.crossplane.io/stable >/dev/null 2>&1 || true
helm repo update >/dev/null
helm upgrade --install crossplane crossplane-stable/crossplane -n crossplane-system --create-namespace --wait --timeout=300s
for ns in platform tenants; do kubectl create ns "$ns" --dry-run=client -o yaml | kubectl apply -f -; done

cat > "$LAB_DIR/00-platform-api-broken.yaml" <<'YAML'
apiVersion: apiextensions.k8s.io/v1
kind: CustomResourceDefinition
metadata:
  name: appclaims.platform.cnpe.io
spec:
  group: platform.cnpe.io
  scope: Namespaced
  names:
    plural: appclaims
    singular: appclaim
    kind: AppClaim
    shortNames: ["aclaim"]
  versions:
  - name: v1alpha1
    served: true
    storage: true
    schema:
      openAPIV3Schema:
        type: object
        properties:
          spec:
            type: object
            properties:
              image:
                type: string
              replicas:
                type: integer
              expose:
                type: boolean
              # BUG: manca size
          status:
            type: object
            properties:
              phase:
                type: string
              endpoint:
                type: string
    subresources:
      status: {}
YAML

cat > "$LAB_DIR/01-controller-rbac-broken.yaml" <<'YAML'
apiVersion: v1
kind: ServiceAccount
metadata:
  name: platform-reconciler
  namespace: platform
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: platform-reconciler
rules:
- apiGroups: ["platform.cnpe.io"]
  resources: ["appclaims"]
  verbs: ["get","list","watch"]
# BUG: manca appclaims/status update/patch
- apiGroups: ["apps"]
  resources: ["deployments"]
  verbs: ["get","list","create","patch"]
- apiGroups: [""]
  resources: ["services","configmaps","secrets"]
  verbs: ["get","list","create","patch"]
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: platform-reconciler
subjects:
- kind: ServiceAccount
  name: platform-reconciler
  namespace: platform
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: platform-reconciler
YAML

cat > "$LAB_DIR/02-claims.yaml" <<'YAML'
apiVersion: platform.cnpe.io/v1alpha1
kind: AppClaim
metadata:
  name: portal
  namespace: tenants
spec:
  image: nginx:latest
  replicas: 1
  expose: true
YAML

cat > "$LAB_DIR/03-reconciler-job-broken.yaml" <<'YAML'
apiVersion: batch/v1
kind: Job
metadata:
  name: reconcile-appclaims
  namespace: platform
spec:
  template:
    spec:
      serviceAccountName: platform-reconciler
      restartPolicy: Never
      containers:
      - name: reconcile
        image: bitnami/kubectl:1.33
        command: [sh, -c]
        args:
        - |
          set -eu
          for ns in $(kubectl get ns -o jsonpath='{.items[*].metadata.name}'); do
            for c in $(kubectl -n "$ns" get appclaims.platform.cnpe.io -o jsonpath='{.items[*].metadata.name}' 2>/dev/null || true); do
              image=$(kubectl -n "$ns" get appclaim "$c" -o jsonpath='{.spec.image}')
              replicas=$(kubectl -n "$ns" get appclaim "$c" -o jsonpath='{.spec.replicas}')
              cat <<EOF | kubectl apply -f -
          apiVersion: apps/v1
          kind: Deployment
          metadata:
            name: $c
            namespace: $ns
            labels: {app: $c}
          spec:
            replicas: $replicas
            selector: {matchLabels: {app: $c}}
            template:
              metadata: {labels: {app: $c}}
              spec:
                containers:
                - name: app
                  image: $image
                  ports: [{containerPort: 80}]
          EOF
              # BUG: manca service e status
            done
          done
YAML

cat > "$LAB_DIR/04-crossplane-like-broken.yaml" <<'YAML'
# Risorse Crossplane-like da correggere nelle domande. Se vuoi puoi installare provider-helm/provider-kubernetes,
# ma il lab è pensato per allenare XRD/Composition concepts anche senza cloud.
apiVersion: v1
kind: ConfigMap
metadata:
  name: composition-webapp
  namespace: platform
data:
  selector: "tier=wrong"
  patchSet: "missing-resource-limits"
  transform: "replicas:string-not-int"
YAML

kubectl apply -f "$LAB_DIR/00-platform-api-broken.yaml"
kubectl apply -f "$LAB_DIR/01-controller-rbac-broken.yaml"
kubectl apply -f "$LAB_DIR/02-claims.yaml"
kubectl apply -f "$LAB_DIR/03-reconciler-job-broken.yaml"
kubectl apply -f "$LAB_DIR/04-crossplane-like-broken.yaml"
cat > "$LAB_DIR/README.txt" <<EOF
Crossplane/Self-service hard
Namespaces: crossplane-system platform tenants
Files: $LAB_DIR
EOF
kubectl -n tenants get appclaim
ok "crossplane/selfservice lab pronto"
