# CNPE Crossplane & Self Service Hard

Lab self-service API/Crossplane-like con Crossplane installato.
