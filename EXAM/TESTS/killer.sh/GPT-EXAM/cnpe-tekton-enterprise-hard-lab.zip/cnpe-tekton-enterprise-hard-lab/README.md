# CNPE Tekton Enterprise Hard

Lab Tekton enterprise con Gitea e pipeline rotte.
