#!/usr/bin/env bash
set -euo pipefail

PROFILE="${MINIKUBE_PROFILE:-cnpe-tekton-enterprise-hard}"
K8S_VERSION="${K8S_VERSION:-v1.33.0}"
CPUS="${MINIKUBE_CPUS:-4}"
MEMORY="${MINIKUBE_MEMORY:-10000}"
DRIVER="${MINIKUBE_DRIVER:-docker}"

CALLER_HOME="${HOME}"
if [ -n "${SUDO_USER:-}" ] && [ "${SUDO_USER}" != "root" ]; then
  CALLER_HOME="$(getent passwd "${SUDO_USER}" | cut -d: -f6)"
fi
LAB_DIR="${LAB_DIR:-${CALLER_HOME}/course/tekton-enterprise-hard}"

info(){ echo "[INFO] $*"; }
ok(){ echo "[OK] $*"; }
warn(){ echo "[WARN] $*"; }
die(){ echo "[ERR] $*"; exit 1; }
have(){ command -v "$1" >/dev/null 2>&1; }

for c in minikube kubectl curl; do have "$c" || die "$c non trovato"; done
mkdir -p "$LAB_DIR"

if ! minikube status -p "$PROFILE" >/dev/null 2>&1; then
  minikube start -p "$PROFILE" --driver="$DRIVER" --cpus="$CPUS" --memory="${MEMORY}mb" --disk-size=50g --kubernetes-version="$K8S_VERSION" --force
fi

export KUBECONFIG
KUBECONFIG="$(minikube kubeconfig --no-env -p "$PROFILE" 2>/dev/null || echo "$HOME/.kube/config")"
kubectl cluster-info >/dev/null

GITEA_URL="${GITEA_URL:-http://192.168.1.56:3000/}"
GITEA_TOKEN="${GITEA_TOKEN:-d2fcd54b7a8e2762920d929bfd4456db208659e4}"
GITEA_ORG="${GITEA_ORG:-organization}"
REPO_NAME="${REPO_NAME:-tekton-enterprise-app}"
REPO_URL="${GITEA_URL%/}/${GITEA_ORG}/${REPO_NAME}.git"
if [ "${1:-}" = "--cleanup" ]; then
  kubectl delete ns tekton-pipelines ci build-prod --ignore-not-found --timeout=180s 2>/dev/null || true
  rm -rf "$LAB_DIR"; ok cleanup; exit 0
fi
kubectl apply -f https://storage.googleapis.com/tekton-releases/pipeline/latest/release.yaml
kubectl apply -f https://storage.googleapis.com/tekton-releases/triggers/latest/release.yaml
kubectl apply -f https://storage.googleapis.com/tekton-releases/triggers/latest/interceptors.yaml
kubectl -n tekton-pipelines wait --for=condition=Available deployment --all --timeout=300s
for ns in ci build-prod; do kubectl create ns "$ns" --dry-run=client -o yaml | kubectl apply -f -; done

WORK="$LAB_DIR/repo"
rm -rf "$WORK"; mkdir -p "$WORK/k8s"; cd "$WORK"
cat > app.py <<'PY'
print("tekton enterprise app")
PY
cat > Dockerfile <<'DOCKER'
FROM python:3.12-alpine
WORKDIR /app
COPY app.py .
CMD ["python","app.py"]
DOCKER
cat > k8s/deploy.yaml <<'YAML'
apiVersion: apps/v1
kind: Deployment
metadata:
  name: enterprise-app
spec:
  replicas: 1
  selector:
    matchLabels: {app: enterprise-app}
  template:
    metadata:
      labels: {app: enterprise-app}
    spec:
      containers:
      - name: app
        image: nginx:1.27-alpine
YAML
git init -b main >/dev/null
git config user.email cnpe@example.local; git config user.name "CNPE Lab"
git add .; git commit -m init >/dev/null
curl -sS -X POST "${GITEA_URL%/}/api/v1/orgs/${GITEA_ORG}/repos" -H "Authorization: token ${GITEA_TOKEN}" -H "Content-Type: application/json" -d "{\"name\":\"${REPO_NAME}\",\"private\":false,\"auto_init\":false}" >/dev/null || true
git remote add origin "$REPO_URL" 2>/dev/null || git remote set-url origin "$REPO_URL"
git push -u origin main >/dev/null 2>&1 || warn "push Gitea fallito"

cat > "$LAB_DIR/00-tekton-enterprise-broken.yaml" <<EOF
apiVersion: v1
kind: ServiceAccount
metadata:
  name: pipeline
  namespace: ci
---
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: deployer
  namespace: build-prod
rules:
- apiGroups: ["apps"]
  resources: ["deployments"]
  verbs: ["get","list","create"]
# BUG manca patch/update
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: deployer
  namespace: build-prod
subjects:
- kind: ServiceAccount
  name: default
  namespace: ci
roleRef:
  kind: Role
  name: deployer
  apiGroup: rbac.authorization.k8s.io
---
apiVersion: tekton.dev/v1
kind: Task
metadata:
  name: git-clone
  namespace: ci
spec:
  params:
  - name: url
    type: string
  - name: revision
    type: string
    default: main
  workspaces:
  - name: source
  results:
  - name: commit
  steps:
  - name: clone
    image: alpine/git:2.45.2
    script: |
      #!/bin/sh
      set -eu
      rm -rf "\$(workspaces.source.path)"/*
      git clone --branch "\$(params.revision)" "\$(params.url)" "\$(workspaces.source.path)/src"
      cd "\$(workspaces.source.path)/src"
      git rev-parse HEAD | tee "\$(results.commit.path)"
---
apiVersion: tekton.dev/v1
kind: Task
metadata:
  name: unit-test
  namespace: ci
spec:
  workspaces:
  - name: source
  steps:
  - name: test
    image: python:3.12-alpine
    workingDir: \$(workspaces.source.path)
    script: |
      #!/bin/sh
      set -eu
      python app.py
---
apiVersion: tekton.dev/v1
kind: Task
metadata:
  name: fake-kaniko
  namespace: ci
spec:
  params:
  - name: image
    type: string
  results:
  - name: image-url
  steps:
  - name: build
    image: alpine:3.20
    script: |
      echo "built \$(params.image)"
      echo "\$(params.image)" | tee "\$(results.image-url.path)"
---
apiVersion: tekton.dev/v1
kind: Task
metadata:
  name: scan
  namespace: ci
spec:
  params:
  - name: image
    type: string
  results:
  - name: critical
  steps:
  - name: scan
    image: alpine:3.20
    script: |
      if echo "\$(params.image)" | grep latest; then echo 5; else echo 0; fi | tee "\$(results.critical.path)"
---
apiVersion: tekton.dev/v1
kind: Task
metadata:
  name: deploy
  namespace: ci
spec:
  params:
  - name: image
    type: string
  - name: critical
    type: string
  steps:
  - name: apply
    image: bitnami/kubectl:1.33
    script: |
      #!/bin/sh
      set -eu
      # BUG non controlla critical
      kubectl -n build-prod set image deployment/enterprise-app app="\$(params.image)" || kubectl -n build-prod create deploy enterprise-app --image="\$(params.image)"
---
apiVersion: tekton.dev/v1
kind: Pipeline
metadata:
  name: enterprise-ci
  namespace: ci
spec:
  params:
  - name: repo-url
    type: string
    default: ${REPO_URL}
  - name: revision
    type: string
    default: main
  - name: image
    type: string
    default: example.com/enterprise-app:latest
  workspaces:
  - name: shared
  tasks:
  - name: clone
    taskRef: {name: git-clone}
    params:
    - name: url
      value: \$(params.repo-url)
    - name: revision
      value: \$(params.revision)
    workspaces:
    - name: source
      workspace: shared
  - name: test
    taskRef: {name: unit-test}
    runAfter: [clone]
    workspaces:
    - name: source
      workspace: shared
  - name: build
    taskRef: {name: fake-kaniko}
    runAfter: [test]
    params:
    - name: image
      value: \$(params.image)
  - name: scan
    taskRef: {name: scan}
    runAfter: [build]
    params:
    - name: image
      value: \$(tasks.build.results.image-url)
  - name: deploy
    taskRef: {name: deploy}
    runAfter: [scan]
    params:
    - name: image
      value: \$(tasks.build.results.image-url)
    - name: critical
      value: \$(tasks.scan.results.critical)
---
apiVersion: tekton.dev/v1
kind: PipelineRun
metadata:
  generateName: enterprise-ci-
  namespace: ci
spec:
  serviceAccountName: pipeline
  pipelineRef: {name: enterprise-ci}
  params:
  - name: repo-url
    value: ${REPO_URL}
  - name: revision
    value: main
  - name: image
    value: example.com/enterprise-app:latest
  workspaces:
  - name: shared
    emptyDir: {}
EOF
kubectl apply -f "$LAB_DIR/00-tekton-enterprise-broken.yaml"
cat > "$LAB_DIR/README.txt" <<EOF
Repo: $REPO_URL
Namespace: ci build-prod
EOF
kubectl -n ci get task,pipeline
ok "tekton enterprise lab pronto"
