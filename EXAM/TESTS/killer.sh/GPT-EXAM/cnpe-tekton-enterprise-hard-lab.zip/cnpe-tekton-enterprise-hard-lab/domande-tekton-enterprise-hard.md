# CNPE Tekton Enterprise Hard

## Q1 — Stato iniziale Tekton e repo Gitea.
## Q2 — Esegui PipelineRun e identifica primo failure.
## Q3 — Fix workspace unit-test: repo clonato in src.
## Q4 — Fix git-clone per branch/SHA.
## Q5 — Fix RBAC RoleBinding subject pipeline.
## Q6 — Fix RBAC verbs patch/update deployments.
## Q7 — PipelineRun con image latest deve fallire al gate.
## Q8 — Correggi deploy task per bloccare critical > 0.
## Q9 — PipelineRun con tag non latest deve passare.
## Q10 — Aggiungi finally task che stampa commit e risultato.
## Q11 — Aggiungi result image-url e verifica propagazione.
## Q12 — Aggiungi SBOM task simulato.
## Q13 — Aggiungi Chains/signing simulato con result signed=true.
## Q14 — Crea TriggerBinding Gitea.
## Q15 — Crea TriggerTemplate per PipelineRun.
## Q16 — Crea EventListener NodePort.
## Q17 — Aggiungi CEL filter solo main/release.
## Q18 — Simula webhook Gitea main.
## Q19 — Cleanup tieni ultime 3 PipelineRun.
## Q20 — Final report Gitea→Tekton→Scan→Deploy.