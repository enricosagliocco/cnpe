#!/usr/bin/env bash
set -euo pipefail

PROFILE="${MINIKUBE_PROFILE:-cnpe-progressive-delivery-hard}"
K8S_VERSION="${K8S_VERSION:-v1.33.0}"
CPUS="${MINIKUBE_CPUS:-4}"
MEMORY="${MINIKUBE_MEMORY:-10000}"
DRIVER="${MINIKUBE_DRIVER:-docker}"

CALLER_HOME="${HOME}"
if [ -n "${SUDO_USER:-}" ] && [ "${SUDO_USER}" != "root" ]; then
  CALLER_HOME="$(getent passwd "${SUDO_USER}" | cut -d: -f6)"
fi
LAB_DIR="${LAB_DIR:-${CALLER_HOME}/course/progressive-delivery-hard}"

info(){ echo "[INFO] $*"; }
ok(){ echo "[OK] $*"; }
warn(){ echo "[WARN] $*"; }
die(){ echo "[ERR] $*"; exit 1; }
have(){ command -v "$1" >/dev/null 2>&1; }

for c in minikube kubectl curl; do have "$c" || die "$c non trovato"; done
mkdir -p "$LAB_DIR"

if ! minikube status -p "$PROFILE" >/dev/null 2>&1; then
  minikube start -p "$PROFILE" --driver="$DRIVER" --cpus="$CPUS" --memory="${MEMORY}mb" --disk-size=50g --kubernetes-version="$K8S_VERSION" --force
fi

export KUBECONFIG
KUBECONFIG="$(minikube kubeconfig --no-env -p "$PROFILE" 2>/dev/null || echo "$HOME/.kube/config")"
kubectl cluster-info >/dev/null

if [ "${1:-}" = "--cleanup" ]; then
  kubectl delete ns argo-rollouts flagger-system progressive --ignore-not-found --timeout=180s 2>/dev/null || true
  rm -rf "$LAB_DIR"; ok cleanup; exit 0
fi
helm version >/dev/null 2>&1 || die "helm richiesto"
kubectl create ns progressive --dry-run=client -o yaml | kubectl apply -f -
kubectl create ns argo-rollouts --dry-run=client -o yaml | kubectl apply -f -
kubectl apply -n argo-rollouts -f https://github.com/argoproj/argo-rollouts/releases/latest/download/install.yaml
kubectl -n argo-rollouts wait --for=condition=Available deployment --all --timeout=300s
helm repo add flagger https://flagger.app >/dev/null 2>&1 || true
helm repo update >/dev/null
helm upgrade --install flagger flagger/flagger -n flagger-system --create-namespace --wait --timeout=300s --set meshProvider=kubernetes
helm upgrade --install loadtester flagger/loadtester -n progressive --wait --timeout=180s || true

cat > "$LAB_DIR/00-rollouts-flagger-broken.yaml" <<'YAML'
apiVersion: argoproj.io/v1alpha1
kind: AnalysisTemplate
metadata:
  name: smoke
  namespace: progressive
spec:
  metrics:
  - name: smoke
    count: 1
    successCondition: result == "ok"
    provider:
      job:
        spec:
          template:
            spec:
              restartPolicy: Never
              containers:
              - name: check
                image: alpine:3.20
                command: [sh,-c]
                args: ["echo passed"]
---
apiVersion: argoproj.io/v1alpha1
kind: Rollout
metadata:
  name: shop
  namespace: progressive
spec:
  replicas: 2
  selector:
    matchLabels: {app: shop}
  strategy:
    canary:
      steps:
      - setWeight: 25
      - analysis:
          templates:
          - templateName: smoke
      - setWeight: 100
  template:
    metadata:
      labels: {app: shop}
    spec:
      containers:
      - name: web
        image: nginx:1.27-alpine
        ports:
        - containerPort: 80
---
apiVersion: v1
kind: Service
metadata:
  name: shop
  namespace: progressive
spec:
  selector: {app: shop}
  ports:
  - port: 80
    targetPort: 80
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: api
  namespace: progressive
  labels: {app: api}
spec:
  replicas: 1
  selector:
    matchLabels: {app: api}
  template:
    metadata:
      labels: {app: api}
    spec:
      containers:
      - name: web
        image: nginx:1.27-alpine
        ports:
        - containerPort: 80
---
apiVersion: v1
kind: Service
metadata:
  name: api
  namespace: progressive
spec:
  selector: {app: api}
  ports:
  - port: 80
    targetPort: 80
---
apiVersion: flagger.app/v1beta1
kind: Canary
metadata:
  name: api
  namespace: progressive
spec:
  provider: kubernetes
  targetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: api
  service:
    port: 80
  analysis:
    interval: 10s
    iterations: 2
    threshold: 2
    metrics: []
    webhooks:
    - name: acceptance
      type: pre-rollout
      url: http://flagger-loadtester.progressive/
      timeout: 5s
      metadata:
        type: bash
        # BUG: service canary DNS sbagliato
        cmd: "curl -s http://api-wrong.progressive/ | grep nginx"
YAML
kubectl apply -f "$LAB_DIR/00-rollouts-flagger-broken.yaml"
cat > "$LAB_DIR/README.txt" <<EOF
Progressive delivery hard: namespace progressive
EOF
kubectl -n progressive get rollout,canary,deploy,svc,analysistemplate
ok "progressive delivery lab pronto"
