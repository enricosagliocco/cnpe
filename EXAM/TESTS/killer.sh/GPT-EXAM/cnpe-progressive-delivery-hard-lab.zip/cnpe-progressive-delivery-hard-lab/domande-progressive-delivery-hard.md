# CNPE Progressive Delivery Hard

## Q1 — Stato iniziale Rollouts/Flagger.
## Q2 — Correggi AnalysisTemplate smoke.
## Q3 — Aggiungi pause dopo setWeight 25.
## Q4 — Aggiungi setWeight 50 + pause.
## Q5 — Baseline Rollout Healthy.
## Q6 — Update immagine shop a nginx:1.28-alpine.
## Q7 — Verifica canary paused.
## Q8 — Promote step-by-step.
## Q9 — Rollback revisione precedente.
## Q10 — AnalysisRun dettagli.
## Q11 — Flagger Canary status.
## Q12 — Correggi webhook DNS api-canary.
## Q13 — Trigger Flagger update env/image.
## Q14 — Verifica api-primary/api-canary services.
## Q15 — Simula failure webhook e rollback.
## Q16 — Blue/Green Flagger con provider kubernetes.
## Q17 — Aggiungi load test webhook.
## Q18 — Eventi canary in file.
## Q19 — Cleanup rollout/canary test.
## Q20 — Final report progressive delivery.